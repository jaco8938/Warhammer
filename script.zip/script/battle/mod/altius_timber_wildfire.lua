-- Timber! Wildfire: part of Timber! since v2.1 (it was the add-on !Altius_x_timber_wildfire.pack). It talks to the main
-- script (altius_timber.lua) only through _G.altius_timber_api, version 8 or later (v2.2: a flame tied to its tree falls
-- with it), so the hook stays open to other add-ons. Settings (spread on/off, chance and its range, hop limit, trees
-- and shrubs burning at once, standing burn time) come from the main script's settings through api.setting (version
-- 5); without it the S defaults below apply.
-- Entry kinds (tree, shrub, rock, stump) come from api.kind (version 6); without it every entry is a tree.
-- Fire spreads from a burning tree to standing trees near it and can burn out a whole forest. Only trees Timber! sets
-- on fire (felled by a flaming blast) start a fire; force blasts and monsters never do.
-- While a tree burns (its flame stage), every CHECK_SECONDS it may light each standing tree within the spread radius.
-- The chance over the whole stage is SPREAD_CHANCE, lower for far trees and downhill, higher uphill. With 0.75 a fire
-- in a forest usually spreads until the forest is gone; a gap wider than the spread radius stops it.
-- With CHANCE_RANGE above 0 each fire draws its own chance once, when it starts: SPREAD_CHANCE - CHANCE_RANGE to
-- SPREAD_CHANCE + CHANCE_RANGE (the Forest fires setting: 0.45 to 0.85). One spark then sometimes dies out, sometimes burns
-- part of a forest and sometimes all of it. Trees set alight by the same blast share one draw.
-- A lit tree burns standing for STANDING_SECONDS: a flame at its base, after CLIMB_SECONDS 2-3 flames up the tree (v2.3,
-- CROWN_FLAMES_MIN..MAX at random heights in CROWN_BANDS, lit from the lowest up over about CROWN_STAGGER s), after
-- CHAR_SECONDS it becomes a dead tree of the map (leaves burnt away). Then it falls away from the tree that lit it and
-- burns on the ground with one flame and one ember point (SPREAD_POINTS), then sinks. Its spread checks start
-- CHECK_DELAY after it is lit, as in build 3, so the fire moves at the same speed.
-- Shrubs (shrubs, bushes, flowers ... in the map's tree list) burn and spread faster: a low flame for
-- SHRUB_STANDING_SECONDS, checks from SHRUB_CHECK_DELAY every SHRUB_CHECK_SECONDS, then Timber! burns them in place and
-- they sink (no fall, no dead-tree swap). They have their own queue, speed budget (SHRUB_RATE_MAX), at-once cap and
-- battle cap, so a burning meadow does not slow or stop a wood next to it. Rocks and stumps (stones, stumps, logs) never
-- catch fire.
-- Wildfire adds fire points to Timber!'s own (96) for the battle, so many trees can burn at once.
-- When too many trees burn at once, or fewer than FIRE_ROOM_RESERVE fire points are free (kept for trees felled by
-- blasts), a tree that caught fire waits in a queue and lights later: the fire moves slower, it does not go out.
-- Spread radius, per kind, measured at the start: trees the larger of RADIUS_FACTOR x the median distance to the nearest
-- tree and TREE_K_FACTOR x the median distance to the TREE_K-th nearest tree (woods with evenly spaced trees, whose
-- nearest neighbour alone gives too short a radius), clamped RADIUS_MIN..RADIUS_MAX; shrubs SHRUB_RADIUS_FACTOR x the
-- median distance to the nearest shrub, clamped SHRUB_RADIUS_MIN..SHRUB_RADIUS_MAX. Between a tree and a tree the tree
-- radius counts; between anything and a shrub, the shrub radius.
-- If Timber! or its hook is missing, Timber! is switched off, or spread is switched off in the settings, this script does
-- nothing. Every log line also goes to the debug submod (altius_timber_debug.lua) when it is loaded.

local BUILD = 'Timber! v2.1 (merged, kinds)' -- written to the log at start: tells this copy from the old add-on's
local DEBUG = false -- the log file; the test file switches it on
local LOG_FILE = 'altius_timber_wildfire.txt' -- next to Warhammer3.exe
local TEST_FILE = 'altius_timber_test.txt' -- next to Warhammer3.exe: exposes _G.altius_timber_wildfire_test, logs
local TICK_MS = 100
local API_VERSION = 8 -- flame_at with a tree: the flame falls with the tree (Timber! v2.2)
local SPREAD_POINTS = { 0.5 } -- fire points along a lying tree lit by spread (one in the middle)
-- fire points added per tree allowed to burn from spread (build 4: 184 for 220; v2.3: 2 per tree, 440 for 220, as a
-- standing tree now holds up to 3 flames)
local EXTRA_PER_BURNING = 2.0
local S = {
	SPREAD_CHANCE = 0.75, -- chance over a tree's flame stage to light one neighbour at the nearest spacing
	CHANCE_RANGE = 0, -- each fire's chance is drawn once from SPREAD_CHANCE +- CHANCE_RANGE; 0 = every fire SPREAD_CHANCE
	CHECKS = 4, -- spread checks per burning tree (one more for a big tree)
	FIRST_CHECK = 1.0, -- seconds after a tree felled by a blast starts to burn
	CHECK_DELAY = 2.5, -- seconds after a tree is lit by spread until its first spread check
	CHECK_SECONDS = 1.0,
	SPREAD_MAX_HOPS = 0, -- a tree lit this many trees away from the blast lights no more trees; 0 = no limit
	SPREAD_MAX_BURNING = 220, -- trees lit by spread that still hold fire points
	RATE_MAX = 48, RATE_WINDOW = 12.6, -- at most RATE_MAX trees lit by spread in any RATE_WINDOW seconds (fire speed)
	EXTRA_FIRE_POINTS = 440, -- added to Timber!'s fire points (96) for this battle (follows SPREAD_MAX_BURNING)
	SPREAD_MAX_PER_BATTLE = 4000, -- trees lit by spread per battle; shrubs have the same cap, counted apart
	FIRE_ROOM_RESERVE = 24, -- a queued tree lights only while more than this many fire points are not taken or promised
	LIGHT_PER_TICK = 4, -- queued trees (and as many shrubs) lit per 0.1 s at most
	QUEUE_MAX = 400, -- trees (and as many shrubs) waiting to light; one that catches fire while its queue is full is not lit
	STANDING_SECONDS = 30, -- a lit tree burns standing this long, then falls
	CLIMB_SECONDS = 6, -- the flame moves from the base to the crown this long after the tree is lit
	CHAR_SECONDS = 12, -- the tree becomes a dead tree this long after it is lit
	-- v2.3 (user: "the whole thing lit up ... 2~3 per tree, randomized"): flames up a standing tree after CLIMB_SECONDS.
	-- Heights are parts of the tree height, taken as twice the base-to-bounding-sphere-centre height (inferred: the
	-- sphere centre is about half way up). Each flame takes one band; with 2 flames, 2 of the 3 bands at random.
	CROWN_FLAMES_MIN = 2, CROWN_FLAMES_MAX = 3,
	CROWN_BANDS = { { 0.25, 0.45 }, { 0.45, 0.65 }, { 0.65, 0.85 } },
	CROWN_STAGGER = 2.5, -- seconds: the flames light one after another, from the lowest up, over about this long
	CROWN_SPREAD = 0.8, -- metres: largest sideways offset of a flame from the trunk
	HOLD_SECONDS = 11.1, -- after it falls, a burning tree holds fire points this long (Timber! flames and embers);
	-- api.burn_hold() replaces it when the main script has it (it follows the lying time setting)
	RADIUS_FACTOR = 1.25,
	RADIUS_MIN = 6, RADIUS_MAX = 20, RADIUS_DEFAULT = 12.5,
	TREE_K = 4, TREE_K_FACTOR = 1.07, TREE_K_SEARCH = 30,
	SAMPLE_TREES = 400,
	FAR_FACTOR = 0.5, -- chance factor at the edge of the spread radius (1.0 at the median spacing)
	SLOPE_A = 0.078, -- uphill factor exp(SLOPE_A x slope in degrees)
	SLOPE_MIN = 0.5, SLOPE_MAX = 2.0,
	BIG_TREE_SCALE = 0.75,
	SUMMARY_SECONDS = 10,
	-- shrubs
	SHRUB_FIRST_CHECK = 0.5, -- seconds after a shrub knocked down by a flaming blast starts to burn
	SHRUB_CHECK_DELAY = 1.0, -- seconds after a shrub is lit by spread until its first check
	SHRUB_CHECK_SECONDS = 0.5,
	SHRUB_STANDING_SECONDS = 4, -- a lit shrub burns (low flame at its base) this long, then burns in place and sinks
	SHRUB_HOLD_SECONDS = 4.5, -- then holds fire points this long (api.burn_hold('shrub') replaces it)
	SHRUB_RATE_MAX = 120, -- shrubs lit by spread in any RATE_WINDOW seconds (their own budget)
	SHRUB_MAX_BURNING = 100, -- shrubs lit by spread that still hold fire points (their own budget)
	SHRUB_RADIUS_FACTOR = 1.25, SHRUB_RADIUS_MIN = 2, SHRUB_RADIUS_MAX = 8, SHRUB_RADIUS_DEFAULT = 2.5,
}

local test_file_found = false
do
	local file = io.open(TEST_FILE, 'r')
	if file then file:close(); test_file_found = true; DEBUG = true end
end

local function log(text)
	-- the debug submod (altius_timber_debug.lua) reads every line, with or without the test file
	local sink = _G.altius_timber_debug
	if type(sink) == 'table' and type(sink.wildfire) == 'function' then pcall(sink.wildfire, text) end
	if not DEBUG then return end
	local file = io.open(LOG_FILE, 'a')
	if file then file:write(text, '\n'); file:close() end
end

local api = nil
local set_up = false
local radius, spacing = S.RADIUS_DEFAULT, S.RADIUS_DEFAULT / S.RADIUS_FACTOR -- trees
local shrub_radius, shrub_spacing = S.SHRUB_RADIUS_DEFAULT, S.SHRUB_RADIUS_DEFAULT / S.SHRUB_RADIUS_FACTOR
local burning = {} -- entries in their flame stage: { tree, kind, y, hop, group, next_check, checks_left }
local standing = {} -- lit entries burning standing: { tree, kind, fx, fz, lit_at, hop, group, flame, climbed, charred }
local queues = { tree = {}, shrub = {} } -- entries that caught fire and wait for room to light: { tree, kind, fx, fz, hop, group, d, p, since }
local lit = {} -- tree number -> true once it caught fire from spread (queued or lit)
local live = { tree = {}, shrub = {} } -- battle seconds until which each entry lit by spread holds fire points
local recent = { tree = {}, shrub = {} } -- battle seconds at which entries were lit by spread, inside RATE_WINDOW
local rate_waits = { tree = 0, shrub = 0 }
local lit_by_kind = { tree = 0, shrub = 0 }
local next_meta = nil -- hop and group for the tree api.burn is about to set on fire
local groups = {} -- group number -> entries burnt in that fire
local group_count = 0
local group_chance = {} -- group number -> that fire's drawn chance (only while CHANCE_RANGE > 0)
local last_blast = nil -- { t, x, z, chance }: the last blast's draw, shared by the trees it sets alight at that moment
local spread_total = 0
local capped_total, queue_full, capped_hops, queued_total = 0, 0, 0, 0
local last_summary, summary_dirty = 0, false
local live_max, hop_max, queue_max, room_min, wait_max = 0, 0, 0, nil, 0
local stopped = false

local test_set = {} -- S keys the test hook has set: the settings do not replace them

-- an entry's kind: 'tree', 'shrub', 'rock' or 'stump' (api version 6); every entry is a tree before that
local function kind_of(t)
	if t.kind then return t.kind end -- set on every entry by the main script (api version 6)
	if api and type(api.kind) == 'function' then
		local ok, k = pcall(api.kind, t)
		if ok and type(k) == 'string' then return k end
	end
	return 'tree'
end

-- the main script's settings (api version 5); false when spread is switched off. Without api.setting the S defaults stay.
local function apply_settings()
	if type(api.setting) ~= 'function' then return true end
	local function get(key, current)
		local ok, v = pcall(api.setting, key)
		if ok and type(v) == type(current) then return v end
		return current
	end
	local function assign(skey, value) if not test_set[skey] then S[skey] = value end end
	if get('wf_enable', true) == false then return false end
	assign('SPREAD_CHANCE', math.min(1, math.max(0, get('wf_chance', S.SPREAD_CHANCE))))
	assign('CHANCE_RANGE', math.min(1, math.max(0, get('wf_chance_range', S.CHANCE_RANGE))))
	assign('SPREAD_MAX_HOPS', math.max(0, math.floor(get('wf_hops', S.SPREAD_MAX_HOPS) + 0.5)))
	assign('SPREAD_MAX_BURNING', math.max(1, math.floor(get('wf_max_burning', S.SPREAD_MAX_BURNING) + 0.5)))
	assign('EXTRA_FIRE_POINTS', math.ceil(S.SPREAD_MAX_BURNING * EXTRA_PER_BURNING - 0.001))
	assign('SHRUB_MAX_BURNING', math.max(1, math.floor(get('wf_shrub_max_burning', S.SHRUB_MAX_BURNING) + 0.5)))
	assign('STANDING_SECONDS', math.max(1, get('wf_standing_seconds', S.STANDING_SECONDS)))
	if type(api.burn_hold) == 'function' then
		local ok, hold = pcall(api.burn_hold, 'tree')
		if ok and type(hold) == 'number' then assign('HOLD_SECONDS', hold) end
		ok, hold = pcall(api.burn_hold, 'shrub')
		if ok and type(hold) == 'number' then assign('SHRUB_HOLD_SECONDS', hold) end
	end
	return true
end

local function base_y(t)
	local ok, y = pcall(api.base_y, t)
	return ok and y or nil
end

-- v2.3: where the flames up a standing tree go and when they light (seconds after it was lit), from the lowest up.
-- base: drawn base height; cy: bounding sphere centre height. Without a usable base: one flame at the centre, as before.
local function crown_plan(tree, base, cy)
	if not base or cy - base < 1 then return { { at = S.CLIMB_SECONDS, x = tree.x, y = cy, z = tree.z } } end
	local h = 2 * (cy - base)
	local bands = {}
	for i = 1, #S.CROWN_BANDS do bands[i] = i end
	for i = #bands, 2, -1 do
		local j = math.random(i)
		bands[i], bands[j] = bands[j], bands[i]
	end
	local n = math.min(#bands, math.random(S.CROWN_FLAMES_MIN, S.CROWN_FLAMES_MAX))
	local chosen = {}
	for i = 1, n do chosen[i] = bands[i] end
	table.sort(chosen)
	local plan, at = {}, S.CLIMB_SECONDS
	for k, i in ipairs(chosen) do
		local band = S.CROWN_BANDS[i]
		local f = band[1] + (band[2] - band[1]) * math.random()
		local a, r = math.random() * 2 * math.pi, S.CROWN_SPREAD * math.random()
		plan[k] = { at = at, x = tree.x + r * math.cos(a), y = base + f * h, z = tree.z + r * math.sin(a) }
		at = at + S.CROWN_STAGGER / math.max(1, n - 1) * (0.5 + math.random())
	end
	return plan
end

-- stops the flames of an entry burning standing; tied flames that already fall with their tree are left to Timber!
local function stop_standing_flames(s)
	if not (type(s.flame) == 'table' and s.flame.follow) then api.flame_stop(s.flame) end
	for _, e in ipairs(s.crown or {}) do
		if not (type(e) == 'table' and e.follow) then api.flame_stop(e) end
	end
	s.pending = nil
end

-- median distance from an entry of a kind to its k-th nearest entry of the same kind (within search m), over a sample
-- of the map's entries of that kind; nil when fewer than 10 samples have one
local function measure_spacing(kind, search, k)
	local list = api.trees()
	if not list or #list < 2 then return nil end
	local pool = {}
	for i = 1, #list do if kind_of(list[i]) == kind then pool[#pool + 1] = list[i] end end
	local step = math.max(1, math.floor(#pool / S.SAMPLE_TREES))
	local d = {}
	for i = 1, #pool, step do
		local t = pool[i]
		local near = {}
		for _, o in ipairs(api.trees_near(t.x, t.z, search)) do
			if o ~= t and kind_of(o) == kind then
				local dd = math.sqrt((o.x - t.x) ^ 2 + (o.z - t.z) ^ 2)
				if dd > 0.01 then near[#near + 1] = dd end
			end
		end
		if #near >= k then
			table.sort(near)
			d[#d + 1] = near[k]
		end
	end
	if #d < 10 then return nil end
	table.sort(d)
	return d[math.floor(#d / 2) + 1], #d
end

-- spacing and radius of a pair: between two trees the tree values, else (a shrub on either side) the shrub values
local function pair(from_kind, to_kind)
	if from_kind == 'tree' and to_kind == 'tree' then return spacing, radius end
	return shrub_spacing, shrub_radius
end

-- chance over the flame stage that a burning entry (from, at height fy) lights the standing entry t; base: the fire's
-- own chance (SPREAD_CHANCE when nil)
local function spread_chance(from, fy, t, sp, r, base)
	local dx, dz = t.x - from.x, t.z - from.z
	local d = math.sqrt(dx * dx + dz * dz)
	local p = base or S.SPREAD_CHANCE
	if r > sp then
		local u = math.min(1, math.max(0, (d - sp) / (r - sp)))
		p = p * (1 - (1 - S.FAR_FACTOR) * u)
	end
	local ty = base_y(t)
	if fy and ty and d > 0.01 then
		local slope = math.deg(math.atan((ty - fy) / d))
		p = p * math.min(S.SLOPE_MAX, math.max(S.SLOPE_MIN, math.exp(S.SLOPE_A * slope)))
	end
	return p, d
end

local function live_count(kind, now)
	local keep = {}
	for _, until_t in ipairs(live[kind]) do if until_t > now then keep[#keep + 1] = until_t end end
	live[kind] = keep
	return #keep
end

local function on_burn(tree, x, z)
	local meta = next_meta
	if meta and meta.fall_only then return end
	if not meta then
		group_count = group_count + 1
		meta = { hop = 0, group = group_count }
		if S.CHANCE_RANGE > 0 then
			-- a new fire draws its chance; trees the same blast sets alight (same moment, same blast centre) share it
			local now = api.now()
			if not (last_blast and last_blast.t == now and last_blast.x == x and last_blast.z == z) then
				local c = S.SPREAD_CHANCE + (2 * math.random() - 1) * S.CHANCE_RANGE
				last_blast = { t = now, x = x, z = z, chance = math.min(1, math.max(0, c)) }
				log(('t=%.1f fire %d starts: chance %.2f (drawn from %.2f-%.2f)'):format(now, group_count, last_blast.chance,
					math.max(0, S.SPREAD_CHANCE - S.CHANCE_RANGE), math.min(1, S.SPREAD_CHANCE + S.CHANCE_RANGE)))
			end
			group_chance[group_count] = last_blast.chance
		end
	end
	groups[meta.group] = (groups[meta.group] or 0) + 1
	if S.SPREAD_MAX_HOPS > 0 and meta.hop >= S.SPREAD_MAX_HOPS then capped_hops = capped_hops + 1 end
	local kind = kind_of(tree)
	local shrub = kind == 'shrub'
	burning[#burning + 1] = {
		tree = tree, kind = kind, y = base_y(tree), hop = meta.hop, group = meta.group,
		next_check = api.now() + (shrub and S.SHRUB_FIRST_CHECK or S.FIRST_CHECK),
		checks_left = S.CHECKS + ((not shrub and (tree.scale or 0) > S.BIG_TREE_SCALE) and 1 or 0),
	}
	summary_dirty = true
end

-- entries lit by spread of a kind inside RATE_WINDOW
local function recent_count(kind, now)
	local keep = {}
	for _, t in ipairs(recent[kind]) do if now - t < S.RATE_WINDOW then keep[#keep + 1] = t end end
	recent[kind] = keep
	return #keep
end

-- true when one more entry of the kind can light now
local function room_now(kind, now)
	local cap, rate = S.SPREAD_MAX_BURNING, S.RATE_MAX
	if kind == 'shrub' then cap, rate = S.SHRUB_MAX_BURNING, S.SHRUB_RATE_MAX end
	if (lit_by_kind[kind] or 0) >= S.SPREAD_MAX_PER_BATTLE or live_count(kind, now) >= cap then return false end
	if recent_count(kind, now) >= rate then rate_waits[kind] = rate_waits[kind] + 1; return false end
	local room = api.fire_room()
	if not room_min or room < room_min then room_min = room end
	return room > S.FIRE_ROOM_RESERVE, room
end

-- the entry catches fire: it burns standing (trees: flame at the base, then in the crown; shrubs: a low flame), and its
-- spread checks start
local function light(e, now, room)
	local shrub = e.kind == 'shrub'
	spread_total = spread_total + 1
	lit_by_kind[e.kind] = (lit_by_kind[e.kind] or 0) + 1
	local hold = shrub and (S.SHRUB_STANDING_SECONDS + S.SHRUB_HOLD_SECONDS) or (S.STANDING_SECONDS + S.HOLD_SECONDS)
	local lv = live[e.kind]
	lv[#lv + 1] = now + hold
	local rc = recent[e.kind]
	rc[#rc + 1] = now
	if #lv > live_max then live_max = #lv end
	if e.hop > hop_max then hop_max = e.hop end
	if now - e.since > wait_max then wait_max = now - e.since end
	groups[e.group] = (groups[e.group] or 0) + 1
	local ty = base_y(e.tree)
	local b = {
		tree = e.tree, kind = e.kind, y = ty, hop = e.hop, group = e.group,
		next_check = now + (shrub and S.SHRUB_CHECK_DELAY or S.CHECK_DELAY),
		checks_left = S.CHECKS + ((not shrub and (e.tree.scale or 0) > S.BIG_TREE_SCALE) and 1 or 0),
	}
	burning[#burning + 1] = b
	local st = { tree = e.tree, kind = e.kind, fx = e.fx, fz = e.fz, lit_at = now, hop = e.hop, group = e.group,
		spread = b, hold_until = now + hold }
	if ty then
		st.flame = api.flame_at(e.tree.x, ty, e.tree.z, (shrub and S.SHRUB_STANDING_SECONDS or S.CLIMB_SECONDS) + 0.2, e.tree)
	end
	standing[#standing + 1] = st
	summary_dirty = true
	log(('t=%.1f fire %d hop %d: %s %d lights %s %d at %.1f m (chance %.3f per stage, waited %.1f s, free fire points %s)'):format(
		now, e.group, e.hop, e.from_kind, e.from, e.kind, e.tree.number, e.d, e.p, now - e.since, tostring(room)))
end

-- one spread check of a burning entry: an entry that catches fire lights now or waits in its queue
local function check(b, now)
	if S.SPREAD_MAX_HOPS > 0 and b.hop >= S.SPREAD_MAX_HOPS then return end
	local reach = b.kind == 'shrub' and shrub_radius or math.max(radius, shrub_radius)
	for _, t in ipairs(api.trees_near(b.tree.x, b.tree.z, reach)) do
		if t ~= b.tree and not t.felled and not lit[t.number] then
			local tk = kind_of(t)
			if tk == 'tree' or tk == 'shrub' then
				local sp, r = pair(b.kind, tk)
				local dx, dz = t.x - b.tree.x, t.z - b.tree.z
				if dx * dx + dz * dz <= r * r then
					local p, d = spread_chance(b.tree, b.y, t, sp, r, group_chance[b.group])
					local q = 1 - (1 - math.min(p, 0.95)) ^ (1 / S.CHECKS)
					if math.random() < q then
						local queue = queues[tk]
						if (lit_by_kind[tk] or 0) + #queue >= S.SPREAD_MAX_PER_BATTLE then
							capped_total = capped_total + 1
						elseif #queue >= S.QUEUE_MAX then
							queue_full = queue_full + 1
						else
							lit[t.number] = true
							queued_total = queued_total + 1
							queue[#queue + 1] = { tree = t, kind = tk, fx = b.tree.x, fz = b.tree.z, hop = b.hop + 1, group = b.group,
								d = d, p = p, since = now, from = b.tree.number, from_kind = b.kind }
							if #queue > queue_max then queue_max = #queue end
						end
					end
				end
			end
		end
	end
end

-- lights queued entries of each kind, oldest first, while there is room
local function light_queue(now)
	for _, kind in ipairs({ 'tree', 'shrub' }) do
		local queue = queues[kind]
		local n = 0
		while #queue > 0 and n < S.LIGHT_PER_TICK do
			local e = queue[1]
			if e.tree.felled then
				table.remove(queue, 1)
			else
				local ok, room = room_now(kind, now)
				if not ok then break end
				table.remove(queue, 1)
				light(e, now, room)
				n = n + 1
			end
		end
	end
end

-- with drawn chances: each fire's chance and size, for the summary (the first 12 fires)
local function fire_list()
	if S.CHANCE_RANGE <= 0 then return '' end
	local parts = {}
	for g = 1, group_count do
		if groups[g] and group_chance[g] then
			if #parts == 12 then parts[#parts + 1] = '...'; break end
			parts[#parts + 1] = ('%d (%.2f) %d'):format(g, group_chance[g], groups[g])
		end
	end
	return '; fires (chance) trees: ' .. table.concat(parts, ', ')
end

local function summary(now)
	local largest, count = 0, 0
	for _, n in pairs(groups) do
		count = count + 1
		if n > largest then largest = n end
	end
	log(('t=%.1f summary: fires %d, trees lit by spread %d, largest fire %d trees, spread checks running %d, burning standing %d, ' ..
		'waiting %d (most %d, longest wait %.1f s), holding fire points now %d (most at once %d), longest chain %d hops, ' ..
		'blocked by the battle cap %d, queue full %d, fewest free fire points %s, at hop limit %d, rate limit waits %d; ' ..
		'shrubs: lit %d, waiting %d, holding fire points %d, rate limit waits %d%s'):format(now, count,
		spread_total, largest, #burning, #standing, #queues.tree + #queues.shrub, queue_max, wait_max,
		live_count('tree', now), live_max, hop_max, capped_total, queue_full, tostring(room_min), capped_hops,
		rate_waits.tree, lit_by_kind.shrub or 0, #queues.shrub, live_count('shrub', now), rate_waits.shrub, fire_list()))
end

local function on_tick()
	if not api then
		local a = _G.altius_timber_api
		if type(a) ~= 'table' or (a.version or 0) < API_VERSION then return end
		api = a
		api.on_burn(function(tree, x, z)
			if stopped then return end
			local ok, err = pcall(on_burn, tree, x, z)
			if not ok then
				stopped = true
				log('stopped after an error: ' .. tostring(err))
			end
		end)
		log('Timber! hook found, version ' .. tostring(api.version))
		if type(api.enabled) == 'function' and not api.enabled() then
			stopped = true
			log('Timber! is switched off: Wildfire does nothing in this battle')
			return
		end
	end
	if not api.ready() then return end
	local now = api.now()
	if not set_up then
		set_up = true
		if not apply_settings() then
			stopped = true
			log('fire spread is switched off in the settings: Wildfire does nothing in this battle')
			return
		end
		local counts = { tree = 0, shrub = 0, rock = 0, stump = 0 }
		for _, t in ipairs(api.trees()) do
			local k = kind_of(t)
			counts[k] = (counts[k] or 0) + 1
		end
		-- trees: the larger of the nearest-tree rule and the k-th-nearest rule
		local median, samples = measure_spacing('tree', S.RADIUS_MAX, 1)
		local kth = nil
		if median then
			spacing = median
			kth = measure_spacing('tree', S.TREE_K_SEARCH, S.TREE_K)
			radius = math.min(S.RADIUS_MAX, math.max(S.RADIUS_MIN, median * S.RADIUS_FACTOR, (kth or 0) * S.TREE_K_FACTOR))
		end
		local smedian = nil
		if counts.shrub > 0 then
			smedian = measure_spacing('shrub', S.SHRUB_RADIUS_MAX, 1)
			if smedian then
				shrub_spacing = smedian
				shrub_radius = math.min(S.SHRUB_RADIUS_MAX, math.max(S.SHRUB_RADIUS_MIN, smedian * S.SHRUB_RADIUS_FACTOR))
			end
		end
		local extra = S.EXTRA_FIRE_POINTS + (counts.shrub > 0 and S.SHRUB_MAX_BURNING or 0)
		local total = api.add_fire_points(extra)
		log(('set-up: trees %d, nearest-tree spacing %s m (from %s trees), spread radius %.1f m, chance %.2f%s, ' ..
			'max hops %s, max holding fire points %d, max per battle %d, fire point reserve %d, fire points %s, ' ..
			'standing burn %d s'):format(#api.trees(),
			median and ('%.1f'):format(median) or 'not measured', tostring(samples), radius, S.SPREAD_CHANCE,
			S.CHANCE_RANGE > 0 and (' (each fire %.2f-%.2f)'):format(math.max(0, S.SPREAD_CHANCE - S.CHANCE_RANGE),
				math.min(1, S.SPREAD_CHANCE + S.CHANCE_RANGE)) or '',
			S.SPREAD_MAX_HOPS > 0 and tostring(S.SPREAD_MAX_HOPS) or 'none', S.SPREAD_MAX_BURNING,
			S.SPREAD_MAX_PER_BATTLE, S.FIRE_ROOM_RESERVE, tostring(total), S.STANDING_SECONDS))
		log(('set-up kinds: tree %d, shrub %d, rock %d, stump %d; tree %d-th nearest %s; shrub spacing %s, shrub radius %.1f m, ' ..
			'shrub cap %d, shrub rate %d per %.1f s'):format(counts.tree, counts.shrub, counts.rock or 0, counts.stump or 0,
			S.TREE_K, kth and ('%.1f m'):format(kth) or 'not measured', smedian and ('%.1f m'):format(smedian) or 'not measured',
			shrub_radius, S.SHRUB_MAX_BURNING, S.SHRUB_RATE_MAX, S.RATE_WINDOW))
	end
	-- entries burning standing: trees' flame climbs to the crown and their leaves burn away; then the entry falls (a
	-- shrub burns in place) and burns
	local keep = {}
	for _, s in ipairs(standing) do
		local age = now - s.lit_at
		local shrub = s.kind == 'shrub'
		if s.tree.felled then
			-- felled by something else (a blast, a monster): its standing flame falls with it and goes out (Timber! does
			-- that for a tied flame), it lights no more entries and frees its place under the at-once cap (a flaming blast
			-- burns it again as a new fire)
			stop_standing_flames(s)
			s.spread.checks_left = 0
			local lv = live[s.kind]
			for i, until_t in ipairs(lv) do
				if until_t == s.hold_until then table.remove(lv, i); break end
			end
			log(('t=%.1f %s %d was felled by something else while it burned standing'):format(now, s.kind, s.tree.number))
		elseif age >= (shrub and S.SHRUB_STANDING_SECONDS or S.STANDING_SECONDS) then
			-- the standing flame is tied to the tree: api.burn fells it and the flame falls with it, then goes out
			next_meta = { fall_only = true }
			local ok, done = pcall(api.burn, s.tree, s.fx, s.fz, SPREAD_POINTS)
			next_meta = nil
			if not ok or not done then
				stop_standing_flames(s)
				log(('t=%.1f %s %d did not burn (fire off or an error)'):format(now, s.kind, s.tree.number))
			end
		else
			if not shrub and not s.climbed and age >= S.CLIMB_SECONDS then
				s.climbed = true
				local ok, cx, cy, cz = pcall(api.crown, s.tree)
				if ok and cy then
					api.flame_stop(s.flame)
					s.crown, s.pending = {}, crown_plan(s.tree, s.spread.y, cy)
				end
			end
			-- v2.3: the flames up the tree light one after another; each burns until the tree falls
			if s.pending then
				local left = {}
				for _, p in ipairs(s.pending) do
					if age >= p.at then
						s.crown[#s.crown + 1] = api.flame_at(p.x, p.y, p.z, S.STANDING_SECONDS - age + 0.2, s.tree)
					else
						left[#left + 1] = p
					end
				end
				s.pending = #left > 0 and left or nil
			end
			if not shrub and not s.charred and age >= S.CHAR_SECONDS then
				s.charred = true
				pcall(api.char, s.tree)
			end
			keep[#keep + 1] = s
		end
	end
	standing = keep
	-- spread checks of burning entries
	keep = {}
	for _, b in ipairs(burning) do
		while b.checks_left > 0 and now >= b.next_check do
			check(b, now)
			b.checks_left = b.checks_left - 1
			b.next_check = b.next_check + (b.kind == 'shrub' and S.SHRUB_CHECK_SECONDS or S.CHECK_SECONDS)
		end
		if b.checks_left > 0 then keep[#keep + 1] = b else summary_dirty = true end
	end
	burning = keep
	light_queue(now)
	-- a summary every SUMMARY_SECONDS while fires burn, and one when the last fire is out
	if summary_dirty and (now - last_summary >= S.SUMMARY_SECONDS
		or (#burning == 0 and #standing == 0 and #queues.tree == 0 and #queues.shrub == 0)) then
		summary_dirty = false
		last_summary = now
		summary(now)
	end
end

_G.altius_timber_wildfire_build = BUILD
if DEBUG then log('---- battle start, Wildfire of ' .. BUILD .. ' loaded') end

-- live test hook: only when the test file exists next to Warhammer3.exe
do
	if test_file_found then
		_G.altius_timber_wildfire_test = {
			set = function(key, value)
				if S[key] == nil or type(value) ~= type(S[key]) then return 'unknown setting ' .. tostring(key) end
				S[key] = value
				test_set[key] = true
				log(('test: %s set to %s'):format(key, tostring(value)))
				return key .. ' = ' .. tostring(value)
			end,
			get = function(key) return S[key] end,
		}
	end
end

pcall(function()
	bm:repeat_callback(function()
		if stopped then return end
		local ok, err = pcall(on_tick)
		if not ok then
			stopped = true
			log('stopped after an error: ' .. tostring(err))
		end
	end, TICK_MS, 'altius_timber_wildfire_tick')
end)
