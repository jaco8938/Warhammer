-- Timber!: explosions fell the battle trees they hit.
-- Every explosion (artillery shells, explosive spells, vortexes) hits the trees inside its blast radius. A tree has a
-- few hit points (no UI): a hit takes 1, or 2 inside half the blast radius, and a big blast (radius HP_BIG_RADIUS or
-- more, e.g. Comet of Casandora) fells it at once. A vortex hits the trees it passes over every VORTEX_HIT_SECONDS.
-- A hit that leaves the tree standing leans it a little away from the blast. At 0 the tree is felled: it loses its
-- collision at once (units walk through, missiles fly through), tips over away from the blast, lies on the ground,
-- sinks into it, then is removed with its shadow.
-- A felled or hit tree tips along the flight of the shell that hit it (trees at the edge of the blast also away from its
-- centre), or along a vortex's path. Heavy monsters (units in altius_timber_heavy_units.lua, by the main unit key that
-- unit:type() gives, with their mass) push over trees when monsters are on (off by default), unless they are flying: the
-- heaviest (mass walk_mass, 9000, or more) the trees they walk into; the others
-- (mass melee_mass, 3000, up to walk_mass) the trees in front of them every melee_seconds (2 s) while they are in melee.
-- Solid shot (cannonballs: projectiles with no explosion and a mass of 300 or more) fells the tree whose trunk it hits,
-- in one hit, away from the cannon; a flaming ball (the Grand Cannon's) sets it on fire like a flaming blast.
-- A tree felled by a flaming blast (ignition amount above 0, as the game's flaming attacks) burns while it lies:
-- flames along its whole length, then its leaves burn away (it becomes a dead tree of the map, if the map has one, and
-- its crown gets thinner), then embers glow along it until it sinks. A tree felled by a force blast only falls.
-- Wildfire (altius_timber_wildfire.lua, same pack): fire spreads from burning trees to the trees around them.
-- The map's tree list also holds shrubs, flowers, stones, stumps and logs. Each entry gets a kind from its model file
-- name (KIND_WORDS): rocks and stumps fall to blasts but never burn; shrubs take one hit, never tip over (they sink,
-- burning or not) and burn shorter, in place. With fire off (Fire "Off", the default) nothing touches shrubs: blasts,
-- vortexes and monsters leave them as they are.
-- Settings: the CFG table below. With the Mod Configuration Tool (MCT, optional), its Timber! page
-- (script/mct/settings/altius_timber.lua: five simple choices, each a preset of CFG values, PRESETS) replaces them while
-- the battle loads; the caves are installed only then, and not at all when Timber! is switched off there.
--
-- How it works (Warhammer3.exe of 2026-10-15; every site is found by its bytes, so a moved function is still found):
--   Two code caves (memreader Plus code_cave; they run on the battle thread and only store values):
--   1. Entry of the function that collides one body with its neighbours: stores the body's owner. owner + 0x58 = world.
--   3. Entry of the function that builds every projectile explosion (0x1430ade38): for shells r9 = projectile + 0x10;
--      stores the projectile position (+ 0xF4, + 0xFC) and velocity (+ 0x100..+ 0x108) in a 64-slot ring. An impact
--      takes the flight of the nearest shell whose flight line passes through it (the blast lands up to one frame
--      before or after the shell). Optional: without it trees fall away from the blast centre.
--   4. Entry of the projectile impact function (0x1430be74c): rcx = projectile, rdx = &surface normal, r8 = &contact
--      point. Stores a contact of solid shot only: record (projectile + 0x90) + 0x40 explosion = 0, + 0xC0 mass >= 300,
--      normal |y| < 0.5 (a trunk, not the ground); slot = contact, normal x / z, ignition (record + 0xD8), velocity.
--      Found by the shot probe (timber_shot_probe, 2026-10-18). Optional: without it cannonballs fell nothing.
--   2. Entry of the constructor every area effect (explosion, vortex) is built with: r9 = landing position, r8 = effect
--      record (+ 4 = a radius, 6 m for every explosion). Stores position, radii, caller and the effect object in a
--      64-slot ring. The blast radius is read from the effect object on the next tick: object + 0x24 is the radius
--      the damage code uses (Comet of Casandora 20 m, Hellstorm shells 6 m, Burning Head 7 m). If that read fails
--      a sanity check, the record's 6 m is used.
--   Tree data, all reached from world:
--     + 0x64540 -> + 0xf0: tree records (0x12 bytes: x, y, z, scale, rotation, flags), one list per tree model.
--     + 0x64600 -> + 0x1d0: drawn trees, + 0x58 = instances (0x98 bytes: bounding sphere, box, two 3x4 matrices).
--     + 0x440 -> + 0x150: tree bodies (+ 0x178 map tree number -> body number, + 0x164 count, + 0x168 bodies);
--       body + 0x68 bit 0 = collision on.
--   Shadows: battle trees use a cached shadow map; the handler of the console command reset_static_shadows redraws it.
--   Fire: composite scenes drawn by the engine's own scene player (as vortexes do): flames (three looks, one picked at
--     random per fire point) and embers, at 3 points along the lying tree, in stages (FIRE_STAGES). v2.3: the scenes
--     are the pack's copies of Flame Storm and Burning Wrath with the campaign hero-action fire in place of their
--     effects (tools/make_timber_scenes.py); each point's size follows the tree's bounding sphere radius.
--     create FUN_141b80238(scene_cache, CA::String name, loop) -> player (vtable 0x1437B3840), scene_cache =
--     [[world + 0x64600] + 0x160]; draw one frame = player vtable slot 1 (player, dt, &matrix4x4, nil, 1.0, 1, 1, 0, 0).
--     A scene's effects keep burning after the draw calls stop, so each stage ends with a player reset
--     FUN_141b88a2c(player, scene, loop), which stops them; the player then goes back to a pool.
--     Only scenes the battle preloaded have their particle effects, so the pack's db adds both scenes to the vortex
--     scene group wh3_dlc23_mom_diabolical_puppetry (the scene group of a pre-battle army ability, preloaded in every
--     battle) with a trigger delay of 100000 s: the battle preloads them and they never play with that ability.
--     While a burning tree lies, it becomes a dead tree model of the map: the drawn instance's 16-bit model index at
--     + 0x94 points into the map's tree model list (model file name at list entry + 0x18; names with '_dead').
--     If no fire scene is in the cache, or a check fails, trees fall without fire.
--   Flaming: the ignition amount is read from memory, following the class's getter in vtable slot 14 (+ 0x70):
--     'mov rax, [rcx + A]; movss xmm0, [rax + B]; ret' = [[object + A] + B] (vortex 0x1439041C0: A 0x100, B 0x58, the
--     field the game's own "ignition amount of the vortex" UI function reads; explosion 0x1439135E8: A 0x108, B 0x50);
--     'movss xmm0, [rcx + X]; ret' (class 0x143914028: X holds the detonation damage, not ignition): that class keeps
--     its explosion record at + 0x108 too, so [[object + 0x108] + 0x50]. Any other getter: treated as force.
-- Hook: _G.altius_timber_api (version 8) lets Wildfire, or another pack, read the trees, their kinds and the settings, hear when a
-- tree starts to burn, see how many fire points are free, add fire points, turn a standing tree into a dead tree, and
-- set a tree on fire (with fewer fire points if it asks). Version 8: a flame can be tied to a tree (flame_at with a
-- tree); when the tree is felled the flame falls with it. Timber! does nothing more with it on its own.
-- Debug hook (version 7): when the debug submod (!Altius_x_timber_debug.pack) sets _G.altius_timber_debug, Timber!
-- reports to it what it does (dbg below): blasts, fells and what caused them, leans, removals, heavy units, the errors it
-- caught and went on from, and how long its tick and frame pass take. Without the submod nothing changes.
-- If any site or check does not match (a game patch), the script changes nothing and the battle plays as vanilla.
-- Needs memreader Plus. Changes the battle model; multiplayer is not tested. The caves stay until the game closes and
-- are reused by later battles.

local TICK_MS = 100
local FRAME_MS = 10
local DROP = 1000 -- metres a removed tree is moved down
local MIN_RADIUS = 2.0
local HP_BASE = 3 -- hit points of a tree
local HP_BIG_TREE = 1 -- extra hit points for a big tree
local BIG_TREE_SCALE = 0.75 -- tree record scale above which a tree is big
local HP_BIG_RADIUS = 15 -- blasts with this radius or more fell every tree they cover in one hit
local VORTEX_HIT_SECONDS = 0.5 -- a moving vortex hits a tree inside it this often
local LEAN_PER_POINT = math.rad(5) -- lean away from the blast per hit point lost, for a tree still standing
local LEAN_TIME = 0.3 -- seconds a lean takes
local MAX_RADIUS = 60 -- an object radius above this is treated as a bad read
local OBJECT_RADIUS = 0x24 -- effect object field with the blast radius
local EFFECT_VTABLE_LOW, EFFECT_VTABLE_HIGH = '0000000143800000', '00000001439FFFFF' -- area effect vtables lie here
local FALL_TIME = 1.6 -- seconds from standing to lying
local LIE_TIME = 8.0 -- seconds lying on the ground
local SINK_TIME = 3.0 -- seconds sinking into the ground before removal
local SINK_DEPTH = 6.0 -- metres a lying tree sinks
local REST_ANGLE = math.rad(85) -- trunk angle from vertical when lying
local BUCKET = 16 -- metres per side of the tree lookup grid
local RING_SLOTS = 64
local SLOT_BYTES = 64
local WATCH_SECONDS = 1.0 -- how long a new effect is watched for movement
local FOLLOW_SECONDS = 60 -- longest a moving effect is followed
local MAX_WATCH = 200
local MOVE_MIN = 0.5 -- metres per tick that count as movement
local MOVE_MAX = 30 -- metres per tick above which a read is treated as invalid
local SHADOW_RESET_AGAIN_MS = 1500
local MAX_MODELS = 512
local DIR_CAVE_SITE = '48 8B C4 48 89 58 10 48 89 70 18 48 89 78 20 55 41 54 41 55 41 56 41 57 48 8D 68 D1 48 81 EC D0 00 00 00 0F 29 70 C8 0F'
local DIR_SLOTS, DIR_SLOT_BYTES = 64, 32
local DIR_MATCH = 1.0 -- metres to the side of a shell's flight line within which an impact counts as its blast
local DIR_AHEAD = 0.1 -- seconds of travel before or after the shell's recorded position where its blast may land
local DIR_EDGE_WEIGHT = 0.7 -- at the blast edge, how much a tree also falls away from the centre
-- cave 4, solid shot (bytes from tools/shot_cave_asm.py; check them with tools/emulate_shot_cave.py)
local SHOT_CAVE_SITE = '4C 8B DC 49 89 5B 10 49 89 6B 18 49 89 7B 20 41 54 41 56 41 57 48 83 EC 60 48 8B 81 90 00 00 00'
local SHOT_SLOTS, SHOT_SLOT_BYTES = 256, 32
local SHOT_CAVE_HEAD = '\80\65\82\65\83\76\139\145\144\0\0\0\77\133\210\15\132\159\0\0\0\73\131\122\64\0\15\133\148\0\0\0\65\129\186\192\0\0\0\0\0\150\67\15\140\131\0\0\0\139\66\4\37\255\255\255\127\61\0\0\0\63\15\131\112\0\0\0\65\139\0\65\11\64\4\65\11\64\8\15\132\95\0\0\0\73\187'
local SHOT_CAVE_TAIL = '\65\139\3\65\255\3\37\255\0\0\0\193\224\5\77\141\92\3\16\65\139\0\65\137\3\65\139\64\4\65\137\67\4\65\139\64\8\65\137\67\8\139\2\65\137\67\12\139\66\8\65\137\67\16\65\139\130\216\0\0\0\65\137\67\20\139\129\0\1\0\0\65\137\67\24\139\129\8\1\0\0\65\137\67\28\65\91\65\90\88'
local SHOT_CAVE_IMM_AT, SHOT_CAVE_SHIFT_AT = 87, 108
local SHOT_REACH = 2.5 -- metres from a cannonball's contact point to the base of the tree it hit (trunks: up to 2 m)
local HEAVY_REACH = 1.0 -- metres beyond a heavy unit's entity radius in which it pushes trees over
local HEAVY_RADIUS_MAX = 8 -- largest entity radius used
local HEAVY_RESCAN_TICKS = 50 -- how often the list of heavy units in the battle is rebuilt
local MELEE_REACH = 3.0 -- metres beyond a melee-tier unit's entity radius that its attacks reach
local MELEE_CONE = 0.5 -- cosine of the half-angle in front of it (60 degrees)
local MELEE_SWING_TICKS = 20 -- ticks between two tree-felling attacks (2 s)
local Y_FIELDS = { 0x0C, 0x1C, 0x28, 0x4C, 0x7C }
-- fire on felled trees: two kinds of composite scene, in stages (seconds after the tree is felled). v2.2: the pack's own
-- copies of Flame Storm and Burning Wrath come first; they look the same but have no sound and no camera shake (the
-- vanilla scenes play the spell's sound and shake the camera at every fire point). The fire's sound then plays from at
-- most SOUND.max sound emitters (kind 'sound': Flame Storm's fire loop alone). If the copies are not loaded, the vanilla
-- scenes are used as before, with their sound, and there are no sound emitters.
-- v2.3: the copies draw the campaign hero-action fire (flames, embers, smoke, light) instead of Flame Storm's swirl and
-- Burning Wrath. scale = matrix scale for the pack's own scene (files[1]); old_scale = for a vanilla scene further down
-- the list. flame_b and flame_c are two more flame looks; each flame point picks one of the flame kinds at random.
local FIRE_KINDS = {
	flame = { files = { 'altius_timber_flame.csc', 'flame_storm.csc', 'flame_storm_upgraded.csc', 'the_burning_head.csc' },
		scale = 0.4, old_scale = 0.2, flame = true },
	flame_b = { files = { 'altius_timber_flame_b.csc' }, scale = 0.4, flame = true }, -- tall flames, heavy smoke
	flame_c = { files = { 'altius_timber_flame_c.csc' }, scale = 0.4, flame = true }, -- low and wide, more sparks
	ember = { files = { 'altius_timber_embers.csc', 'wh3_dlc23_burning_wrath_vortex.csc' }, scale = 0.45, old_scale = 0.3 },
	sound = { files = { 'altius_timber_fire_sound.csc' }, scale = 1.0 },
}
local SOUND = { -- sound emitters (one table: this file is close to Lua's limit of 200 file-level locals)
	silent_flame = 'altius_timber_flame.csc', -- with this flame scene the sound comes from the sound emitters
	max = 1, -- sound emitters at most (CFG.sound_max; v2.3: 1, was 4)
	cell = 40, -- metres: burning fire points are grouped in cells this big; each emitter plays for one cell
	ticks = 10, -- the emitters are placed again every this many ticks (1 s)
	distance = 30, -- metres from the camera target at which a cell's score is halved (v2.3: 30 and squared, so the one
	-- emitter plays at the fire the camera looks at; v2.2: 150, not squared)
	speed = 20, -- metres per second an emitter glides towards its cell
	jump = 120, -- metres: an emitter farther than this from its cell moves there at once
}
local FIRE_STAGES = { -- kind, start, end
	{ 'flame', 0.5, FALL_TIME + 3.0 },
	{ 'ember', FALL_TIME + 2.5, FALL_TIME + LIE_TIME + 1.0 },
}
local DEAD_SWAP = FALL_TIME + 2.0 -- the tree becomes a dead tree of the map at this time
local DEAD_WORDS = { '_dead', 'burnt', 'burned' } -- model file names with one of these are dead trees
-- the kind of a tree-list entry, from its model file name (lower case; first rule that matches); anything else is a tree
local KIND_WORDS = {
	{ 'rock', { 'stone', 'rock' } },
	{ 'stump', { 'stump', '_log' } }, -- stumps and logs
	{ 'shrub', { 'shrub', 'bush', 'flower', 'fern', 'bracken', 'reed', 'grass', 'plant' } },
}
local SHRUB_LIE = 0.5 -- seconds a shrub knocked down without fire stays in place before it sinks
local SHRUB_BURN = 3.0 -- seconds a burning shrub burns in place before it sinks
local SHRUB_POINTS = { 0.5 } -- one fire point, in the middle of the shrub
local SHRUB_STAGES = { -- a burning shrub: kind, start, end (it does not fall, so the burn starts at once)
	{ 'flame', 0.0, SHRUB_BURN },
	{ 'ember', SHRUB_BURN - 0.5, SHRUB_BURN + 1.0 },
}
local FIRE_MAX = 96 -- fire points burning at once; a point waits for a free slot (flames give up after FLAME_WAIT s)
local FLAME_WAIT = 0.5
local FIRE_POINTS = { 0.15, 0.5, 0.85 } -- fire points along the lying tree, as parts of its length from the base
local CROWN_MIN = 0.6 -- width of a burnt crown, as a part of its width
local CROWN_BURN_START = 1.0 -- seconds after a burning tree lies down that its crown starts to burn away
local MODEL_FIELD = 0x94 -- drawn tree instance: 16-bit index into the map's tree model list
local FIRE_MAX_DT = 0.1
local CREATE_SITE = '48 89 5C 24 08 57 48 83 EC 20 41 8A D8 41 B0 01 E8 ?? ?? ?? ?? B9 30 00 00 00 48 8B F8 E8 ?? ?? ?? ?? 48 8B C8 33 C0 48 85 C9 74 ?? 44 8A C3 48 8B D7 E8'
local PLAYER_VTABLE_FROM_CREATE = { 0x1000000, 0xC33608 } -- 0x1437B3840 - 0x141B80238, in exact steps
-- scene player reset FUN_141b88a2c(player, scene, loop): stops the scene's effects (they keep burning without it)
local RESET_PLAYER_SITE = '48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 20 41 8A D8 48 8B EA 48 8B F1 E8 ?? ?? ?? ?? 33 FF 88 5E 28 48'
local DRAW_SIGNATURE = 'void(pointer, float, pointer, pointer, float, uint8, uint8, uint8, uint8)'
local TEST_FILE = 'altius_timber_test.txt' -- next to Warhammer3.exe: exposes _G.altius_timber_test for live tests
local TEST_LOG = 'altius_timber_test_log.txt' -- test mode only: one line per blast
local IGNITION_SLOT = 0x70 -- area effect vtable slot 14: the ignition getter
local EXPLOSION_RECORD, EXPLOSION_IGNITION = 0x108, 0x50 -- explosion object: record pointer; record: ignition amount
local CODE_LOW, CODE_HIGH = '0000000140001000', '0000000143FFFFFF'
local test_mode = false
do
	local file = io.open(TEST_FILE, 'r')
	if file then file:close(); test_mode = true end
end

-- settings: these defaults, or the values of the MCT page's choices (read once, while the battle loads).
-- Wildfire's keys (wf_) are read by altius_timber_wildfire.lua through api.setting.
-- The defaults play like Timber! v1 (user, 2026-10-18), with or without MCT: one hit fells a tree, no fire, no monsters.
-- Fire, wildfire and monsters are turned on on the MCT page.
local SETTINGS_MOD = 'altius_timber' -- MCT mod key
-- a mass no unit has: walk_mass and melee_mass with monsters off. Not math.huge: it is nil in the game's Lua, and a
-- nil setting made the monster scan fail every 5 s with monsters off (live run 25, 2026-10-18).
local NEVER = 1e9
local CFG = {
	enable = true, -- off: no caves, no callbacks, the battle plays as vanilla
	hp_base = 1, -- hits a tree takes: HP_BASE; v1: one hit
	hp_big = 0, -- extra hits a big tree takes: HP_BIG_TREE; v1: none (any hit fells any tree)
	big_radius = 10, -- blasts this big (m) fell every tree they cover at once: HP_BIG_RADIUS
	shot_direction = true, -- trees fall the way the shot flew (cave 3); off: away from the blast centre
	vortex = true, -- moving vortex spells fell the trees along their path
	solid_shot = true, -- cannonballs (solid shot, no explosion) fell the trees they hit (cave 4)
	fire = false, -- flaming attacks set felled trees on fire (and so start wildfires); v1: no fire
	fire_max = 96, -- Timber!'s own fire points: FIRE_MAX (Wildfire adds its own)
	sound_max = 1, -- sound emitters at most: SOUND.max (v2.2; 0 = no fire sound; v2.3: 1, was 4)
	walk_mass = NEVER, -- units at least this heavy walk through trees; v1: no monsters
	melee_mass = NEVER, -- units at least this heavy (and lighter than walk_mass) fell the trees in front of them in melee
	melee_seconds = 2, -- seconds between two tree-felling attacks: MELEE_SWING_TICKS
	lie_seconds = 8, -- seconds a felled tree lies on the ground: LIE_TIME
	wf_enable = false, wf_chance = 0.75, wf_hops = 0, wf_max_burning = 220, wf_standing_seconds = 30, -- Wildfire
	wf_shrub_max_burning = 100, -- Wildfire: shrubs lit by spread holding fire points at once (their own budget)
	wf_chance_range = 0, -- Wildfire: each fire draws its chance once, from wf_chance - range to wf_chance + range
}
-- the MCT page's five choices; each sets some CFG values (the defaults above = enable, weak, off, monsters off, normal)
local PRESETS = {
	strength = {
		weak = { hp_base = 1, hp_big = 0, big_radius = 10 },
		normal = { hp_base = 3, hp_big = 1, big_radius = 15 },
		strong = { hp_base = 5, hp_big = 1, big_radius = 25 },
	},
	fire_mode = { -- MCT key fire_mode (build 3's page had a checkbox 'fire'; a new key keeps its saved value out)
		off = { fire = false, wf_enable = false },
		burn = { fire = true, wf_enable = false },
		small = { fire = true, wf_enable = true, wf_chance = 0.6, wf_hops = 4 },
		-- each fire draws its chance from 0.45 to 0.85: one spark does not always burn the whole forest (user, 2026-10-18)
		forest = { fire = true, wf_enable = true, wf_chance = 0.65, wf_chance_range = 0.2, wf_hops = 0 },
	},
	monsters = {
		[true] = { walk_mass = 9000, melee_mass = 3000 },
		[false] = { walk_mass = NEVER, melee_mass = NEVER },
	},
	effects = {
		normal = { fire_max = 96, wf_max_burning = 220, wf_shrub_max_burning = 100, sound_max = 1 },
		fewer = { fire_max = 48, wf_max_burning = 80, wf_shrub_max_burning = 40, sound_max = 1 },
	},
}
local choices = {} -- what the MCT page said, for the test log
local settings_error = nil -- debug: why reading the MCT page failed
local LEGACY_TIER_MASS = { walk = 9000, melee = 3000 } -- heavy list entries of v2.1 dev: { radius, tier }

local function clamp(v, lo, hi) return math.min(hi, math.max(lo, v)) end

-- the MCT page's choices into CFG (enable, then the presets); false when MCT or the page is not there. A value the page
-- does not know (an older page, a wrong type) changes nothing.
local function read_settings()
	local ok, found = pcall(function()
		if type(get_mct) ~= 'function' then return false end
		local mct = get_mct()
		local mod = mct and mct:get_mod_by_key(SETTINGS_MOD)
		if not mod then return false end
		local function value(key)
			local option = mod:get_option_by_key(key)
			if option then return option:get_finalized_setting() end
			return nil
		end
		local enable = value('enable')
		if type(enable) == 'boolean' then CFG.enable = enable; choices.enable = enable end
		for _, key in ipairs({ 'strength', 'fire_mode', 'monsters', 'effects' }) do
			local v = value(key)
			local preset = v ~= nil and PRESETS[key][v] or nil
			if preset then
				choices[key] = v
				for k, setting in pairs(preset) do CFG[k] = setting end
			end
		end
		return true
	end)
	if not ok then settings_error = tostring(found) end
	return ok and found
end

-- the settings into the values the script reads
local function apply_settings()
	HP_BASE = math.floor(clamp(CFG.hp_base, 1, 20) + 0.5)
	HP_BIG_TREE = math.floor(clamp(CFG.hp_big, 0, 20) + 0.5)
	HP_BIG_RADIUS = clamp(CFG.big_radius, 1, 100)
	FIRE_MAX = math.floor(clamp(CFG.fire_max, 8, 512) + 0.5)
	SOUND.max = math.floor(clamp(CFG.sound_max, 0, 16) + 0.5)
	LIE_TIME = clamp(CFG.lie_seconds, 1, 120)
	FIRE_STAGES[2][3] = FALL_TIME + LIE_TIME + 1.0
	MELEE_SWING_TICKS = math.max(1, math.floor(clamp(CFG.melee_seconds, 0.5, 30) * 1000 / TICK_MS + 0.5))
end

local BODY_CAVE_SITE = '48 89 54 24 10 55 53 56 57 41 54 41 55 41 56 41 57 48 8B EC 48 83 EC 78 48 8D 59 68 48 89 4D 48'
local IMPACT_CAVE_SITE = '48 89 5C 24 10 48 89 6C 24 18 48 89 74 24 20 57 48 83 EC 20 48 8B 42 08 48 8B DA 48 89 41 08 48 8B F9'
local RESET_SITE = '48 83 EC 28 48 8B 0D ?? ?? ?? ?? 48 8B 01 FF 90 30 02 00 00 48 8B C8 E8 ?? ?? ?? ?? 48 8B C8 48 83 C4 28 E9 ?? ?? ?? ??'

local mr = _G.memreader_plus
if not mr then return end

-- byte helpers; binary strings are read with string.byte only (string.sub changes them in the game's Lua)
local function u24(s, i) local a, b, c = s:byte(i, i + 2); return a + b * 256 + c * 65536 end
local function f32(s, i)
	local b1, b2, b3, b4 = s:byte(i, i + 3)
	local sign = b4 >= 128 and -1 or 1
	local e = (b4 % 128) * 2 + math.floor(b3 / 128)
	local m = (b3 % 128) * 65536 + b2 * 256 + b1
	if e == 0 then return sign * math.ldexp(m, -149) end
	if e == 255 then return 0 end
	return sign * math.ldexp(m + 8388608, e - 150)
end
local function f32_bytes(v)
	if v == 0 then return '\0\0\0\0' end
	local sign = 0
	if v < 0 then sign = 128; v = -v end
	local m, e = math.frexp(v)
	local exponent = e + 126
	if exponent <= 0 then return '\0\0\0\0' end
	local mantissa = math.floor((m * 2 - 1) * 8388608 + 0.5)
	if mantissa >= 8388608 then mantissa = 0; exponent = exponent + 1 end
	if exponent >= 255 then exponent = 254; mantissa = 8388607 end
	return string.char(mantissa % 256, math.floor(mantissa / 256) % 256,
		math.floor(mantissa / 65536) + (exponent % 2) * 128, sign + math.floor(exponent / 2))
end
local function floats_bytes(list)
	local out = {}
	for i = 1, #list do out[i] = f32_bytes(list[i]) end
	return table.concat(out)
end
local function floats_at(s, i, n)
	local out = {}
	for k = 0, n - 1 do out[k + 1] = f32(s, i + k * 4) end
	return out
end
local function u32(p, off) return u24(mr.read(p, off, 4), 1) end
local function float_at(p, off) return f32(mr.read(p, off, 4), 1) end
local function is_null(p) return p == nil or mr.is_null(p) end
local atan2 = math.atan2 or math.atan

local function pointer_bytes(p)
	local text = mr.tostring(p)
	local out = {}
	for i = #text - 1, 1, -2 do out[#out + 1] = string.char(tonumber(text:sub(i, i + 1), 16)) end
	return table.concat(out)
end

-- push rax / mov rax, buffer / mov [rax], rcx / inc qword [rax+8] / pop rax
local function body_cave_bytes(buffer)
	return '\80' .. '\72\184' .. pointer_bytes(buffer) .. '\72\137\8' .. '\72\255\64\8' .. '\88'
end

-- push rax, rcx, rdx / mov rax, buffer / ecx = count, count + 1 / slot = buffer + 16 + (count & 63) * 64 /
-- slot: x, y, z from [r9], radius 4 and radius 8 from [r8 + 4], [r8 + 8], return address, effect object (saved rcx) /
-- pop rdx, rcx, rax
local function impact_cave_bytes(buffer)
	return '\80\81\82' .. '\72\184' .. pointer_bytes(buffer)
		.. '\139\8' .. '\141\81\1' .. '\137\16' .. '\131\225\63' .. '\193\225\6' .. '\72\141\76\8\16'
		.. '\65\139\17' .. '\137\17' .. '\65\139\81\4' .. '\137\81\4' .. '\65\139\81\8' .. '\137\81\8'
		.. '\65\139\80\4' .. '\137\81\12' .. '\65\139\80\8' .. '\137\81\16'
		.. '\72\139\84\36\24' .. '\72\137\81\24'
		.. '\72\139\84\36\8' .. '\72\137\81\32' .. '\90\89\88'
end

-- push rax, rcx, rdx / mov rax, buffer / ecx = count, count + 1 / slot = buffer + 16 + (count & 63) * 32 / zero 5 floats /
-- if r9 (4th argument; projectile + 0x10 for shells) then slot x, z = projectile +0xF4, +0xFC and
-- slot vx, vy, vz = projectile velocity +0x100..+0x108 / pop rdx, rcx, rax
-- (for other callers r9 points into the stack: readable, and their slots never match a blast position)
local function dir_cave_bytes(buffer)
	local function load(disp, store) return string.char(0x41, 0x8B, 0x81, disp, 0x00, 0x00, 0x00) .. store end
	return string.char(0x50, 0x51, 0x52, 0x48, 0xB8) .. pointer_bytes(buffer) .. string.char(
		0x8B, 0x08, 0x8D, 0x51, 0x01, 0x89, 0x10, 0x83, 0xE1, 0x3F, 0xC1, 0xE1, 0x05, 0x48, 0x8D, 0x4C, 0x08, 0x10,
		0x31, 0xC0, 0x89, 0x01, 0x89, 0x41, 0x04, 0x89, 0x41, 0x08, 0x89, 0x41, 0x0C, 0x89, 0x41, 0x10,
		0x4D, 0x85, 0xC9, 0x74, 0x31)
		.. load(0xE4, string.char(0x89, 0x01)) .. load(0xEC, string.char(0x89, 0x41, 0x04))
		.. load(0xF0, string.char(0x89, 0x41, 0x08)) .. load(0xF4, string.char(0x89, 0x41, 0x0C))
		.. load(0xF8, string.char(0x89, 0x41, 0x10))
		.. string.char(0x5A, 0x59, 0x58)
end

-- cave 4: see SHOT_CAVE_* and the header
local function shot_cave_bytes(buffer)
	return SHOT_CAVE_HEAD .. pointer_bytes(buffer) .. SHOT_CAVE_TAIL
end

-- buffer of an existing or new cave; nil if the site is not found or an existing cave has another layout
local function install_cave(site, size, make_bytes, imm_at, check_at, check_byte)
	local at, count = mr.find_pattern(site)
	if count ~= 1 then return nil end
	local info = mr.hook_info(at)
	if info and info.cave then
		if check_at and mr.read(info.cave, check_at, 1):byte(1) ~= check_byte then return nil end
		return mr.read_pointer(info.cave, imm_at)
	end
	local buffer = mr.game_alloc(size)
	local ok, cave = pcall(mr.code_cave, at, make_bytes(buffer))
	if ok and cave then return buffer end
	return nil
end

local body_buffer, impact_buffer -- set by install_caves()
local dir_buffer = nil
local shot_buffer = nil -- cave 4
local shot_last = 0
local shot_count, shot_fells, shot_lost = 0, 0, 0 -- this battle: contacts read, trees felled by them, contacts lost

local tick = 0
local body_last, body_calls_this_battle = 0, 0
local impact_last = 0
local trees = nil
local reset_at = nil
local reset_again_tick = nil
local falling = {}
local dir_last = 0
local dirs = {} -- recent projectile explosions: x, z, vx, vz (unit vector or nil)
local blast_dir = nil -- set while a blast is applied: { x, z, radius, vx, vz }
local heavy = nil -- heavy units in this battle: { unit, radius, lx, lz }
local heavy_scan_tick = nil
local watched = {}
local last_tick_clock = os.clock()
local shadow_reset_wanted = false
local stopped = false -- set when something does not match; the script then does nothing more
local burn_listeners = {} -- submod functions called when a felled tree starts to burn: fn(tree, x, z)
local begun = false -- the settings are read and the script started (or stays off)
local debug_on = false -- the debug submod is there (checked every tick)
local cause = nil -- debug only: what is felling or hitting trees right now ({ by = 'blast', 'vortex', 'walk', 'melee', ... })
local start_info = nil -- debug: how this battle started (settings, caves), for api.debug_start()
local install_why = nil -- debug: why the caves were not installed

-- reports kind and its values to the debug submod; does nothing without it
local function dbg(kind, ...)
	local sink = _G.altius_timber_debug
	if type(sink) == 'table' and type(sink.event) == 'function' then pcall(sink.event, kind, ...) end
end

-- installs the caves (or finds them from an earlier battle) and reads their counters; false when the two main ones are
-- not there
local function install_caves()
	-- every memreader Plus function this script calls; a release without one of them leaves Timber! off for the battle
	-- (no caves, no writes) and the debug submod names it (v2.2, after memreader Plus 0.13.0). A removed or renamed
	-- function reads nil here.
	local missing = {}
	for _, name in ipairs({ 'add', 'alloc', 'call', 'code_cave', 'find_pattern', 'game_alloc', 'hook_info', 'is_null', 'read',
		'read_pointer', 'tostring', 'uint32', 'uint8', 'write' }) do
		if mr[name] == nil then missing[#missing + 1] = name end
	end
	if #missing > 0 then
		install_why = 'memreader Plus lacks ' .. table.concat(missing, ', ')
		return false
	end
	local ok, err = pcall(function()
		body_buffer = install_cave(BODY_CAVE_SITE, 16, body_cave_bytes, 3)
		-- byte 25 of the impact cave is the slot shift (6 = 64-byte slots)
		if body_buffer then
			impact_buffer = install_cave(IMPACT_CAVE_SITE, 16 + RING_SLOTS * SLOT_BYTES, impact_cave_bytes, 5, 25, 6)
		end
	end)
	if not ok or not impact_buffer then
		install_why = not ok and ('error: ' .. tostring(err))
			or (body_buffer and 'impact cave site not found, or a cave of another layout' or 'body cave site not found, or a cave of another layout')
		return false
	end
	-- optional: without it trees fall away from the blast centre (byte 25 of this cave is the slot shift 5)
	if CFG.shot_direction then
		pcall(function() dir_buffer = install_cave(DIR_CAVE_SITE, 16 + DIR_SLOTS * DIR_SLOT_BYTES, dir_cave_bytes, 5, 25, 5) end)
	end
	-- optional: without it cannonballs fell nothing (byte SHOT_CAVE_SHIFT_AT of this cave is the slot shift 5)
	if CFG.solid_shot then
		pcall(function()
			shot_buffer = install_cave(SHOT_CAVE_SITE, 16 + SHOT_SLOTS * SHOT_SLOT_BYTES, shot_cave_bytes, SHOT_CAVE_IMM_AT,
				SHOT_CAVE_SHIFT_AT, 5)
		end)
	end
	local cok, calls = pcall(function() return u24(mr.read(body_buffer, 8, 4), 1) end)
	if cok then body_last = calls end
	cok, calls = pcall(function() return u24(mr.read(impact_buffer, 0, 4), 1) end)
	if cok then impact_last = calls end
	if dir_buffer then
		cok, calls = pcall(function() return u24(mr.read(dir_buffer, 0, 4), 1) end)
		if cok then dir_last = calls end
	end
	if shot_buffer then
		cok, calls = pcall(function() return u24(mr.read(shot_buffer, 0, 4), 1) end)
		if cok then shot_last = calls end
	end
	return true
end

local function reset_shadows()
	if reset_at == nil then
		local at, count = mr.find_pattern(RESET_SITE)
		reset_at = (count == 1) and at or false
	end
	if reset_at then pcall(mr.call, reset_at, 'void()') end
end

-- a CA::String: short form (top nibble of the second 8 bytes = 8: length in bits 56..59, characters inline) or long
-- form (length at + 0, character pointer at + 8)
local function read_ca_string(p)
	local raw = mr.read(p, 0, 16)
	local top = raw:byte(16)
	local out = {}
	if math.floor(top / 16) == 8 then
		for k = 1, top % 16 do out[k] = string.char(raw:byte(k)) end
	else
		local len = u24(raw, 1)
		if len > 400 then return nil end
		local chars = mr.read(mr.read_pointer(p, 8), 0, len)
		for k = 1, len do out[k] = string.char(chars:byte(k)) end
	end
	return table.concat(out)
end

-- true when text ends with a / or \ and then file (file in lower case), by string.byte only
local function is_file(text, file)
	local n, m = #text, #file
	if n <= m then return false end
	for k = 1, m do
		local c = text:byte(n - m + k)
		if c >= 65 and c <= 90 then c = c + 32 end
		if c ~= file:byte(k) then return false end
	end
	local sep = text:byte(n - m)
	return sep == 47 or sep == 92
end

local fire = nil -- the fire state of this battle, nil when trees fall without fire
local fire_clock = nil
local fire_points = FIRE_POINTS
local crown_min = CROWN_MIN
local fire_world = nil

-- text of a C string at p (up to 120 bytes), in lower case, by string.byte only
local function c_text(p)
	local raw = mr.read(p, 0, 120)
	local out = {}
	for k = 1, #raw do
		local c = raw:byte(k)
		if c == 0 then break end
		if c >= 65 and c <= 90 then c = c + 32 end
		out[#out + 1] = string.char(c)
	end
	return table.concat(out)
end

local function has_text(text, word)
	local n, m = #text, #word
	for i = 1, n - m + 1 do
		local k = 1
		while k <= m and text:byte(i + k - 1) == word:byte(k) do k = k + 1 end
		if k > m then return true end
	end
	return false
end

-- 'tree', 'shrub', 'rock' or 'stump' for a model file name (lower case)
local function entry_kind(name)
	for _, rule in ipairs(KIND_WORDS) do
		for _, word in ipairs(rule[2]) do
			if has_text(name, word) then return rule[1] end
		end
	end
	return 'tree'
end

-- indices of the map's dead tree models (the instance model field indexes the tree model list); a dead shrub, stone or
-- stump model is left out, so a burnt tree never turns into one
local function dead_models(world)
	local container = mr.read_pointer(mr.read_pointer(world, 0x64540), 0xf0)
	local sentinel = mr.tostring(mr.add(container, 0x78))
	local entry = mr.read_pointer(container, 0x80)
	local out, names, index = {}, {}, 0
	while not is_null(entry) and mr.tostring(entry) ~= sentinel and index < MAX_MODELS do
		local ok, name = pcall(c_text, mr.read_pointer(entry, 0x18))
		if ok and entry_kind(name) == 'tree' then
			for _, w in ipairs(DEAD_WORDS) do
				if has_text(name, w) then out[#out + 1] = index; names[#names + 1] = name; break end
			end
		end
		index = index + 1
		entry = mr.read_pointer(entry, 8)
	end
	return out, names
end

-- finds the preloaded fire scenes and the engine functions; nil when there is no flame scene
local function fire_setup(world, override)
	local at, count = mr.find_pattern(CREATE_SITE)
	if count ~= 1 then return nil, 'scene player maker found ' .. tostring(count) .. ' times' end
	local reset_at, rcount = mr.find_pattern(RESET_PLAYER_SITE)
	if rcount ~= 1 then return nil, 'scene reset found ' .. tostring(rcount) .. ' times' end
	local cache = mr.read_pointer(mr.read_pointer(world, 0x64600), 0x160)
	if is_null(cache) then return nil, 'no scene cache' end
	local n = u32(cache, 0x24)
	if n > 4000 then return nil, 'scene cache holds ' .. tostring(n) .. ' scenes (too many)' end
	local data = mr.read_pointer(cache, 0x28)
	local names = {}
	for k = 0, n - 1 do
		local ok, name = pcall(read_ca_string, mr.add(mr.read_pointer(data, k * 8), 0x110))
		if ok and name then names[#names + 1] = name end
	end
	local kinds = {}
	for key, spec in pairs(FIRE_KINDS) do
		local files = (override and override[key]) and { override[key] } or spec.files
		local chosen, own = nil, false
		for k, file in ipairs(files) do
			for _, name in ipairs(names) do
				if not chosen and is_file(name, file) then chosen, own = name, (k == 1) end
			end
		end
		if chosen then
			local buffer = mr.alloc(16 + #chosen + 1)
			mr.write(buffer, 16, chosen .. string.char(0))
			mr.write(buffer, 0, mr.uint32(#chosen))
			mr.write(buffer, 4, mr.uint32(#chosen))
			mr.write(buffer, 8, mr.add(buffer, 16))
			kinds[key] = { name = chosen, buffer = buffer, pool = {}, flame = spec.flame,
				scale = (own or not spec.old_scale) and spec.scale or spec.old_scale }
		end
	end
	if not kinds.flame then return nil, 'no flame scene among the ' .. tostring(#names) .. ' preloaded scenes' end
	-- the flame looks a flame point picks from: the variants only go with the pack's own first flame scene
	local flames = { 'flame' }
	if is_file(kinds.flame.name, FIRE_KINDS.flame.files[1]) then
		for _, key in ipairs({ 'flame_b', 'flame_c' }) do
			if kinds[key] then flames[#flames + 1] = key end
		end
	end
	local matrices = {}
	for k = 1, FIRE_MAX do matrices[k] = mr.alloc(64) end
	local dok, dead, dead_names = pcall(dead_models, world)
	-- sound emitters only when the flames are the silent copy (with the vanilla flames the sound comes from each point)
	local silent = is_file(kinds.flame.name, SOUND.silent_flame)
	return {
		sound = (silent and kinds.sound and SOUND.max > 0) and { emitters = {}, next_tick = 0, matrices = {}, most = 0 } or nil,
		create_at = at, reset_at = reset_at, cache = cache, kinds = kinds,
		player_vtable = mr.tostring(mr.add(mr.add(at, PLAYER_VTABLE_FROM_CREATE[1]), PLAYER_VTABLE_FROM_CREATE[2])),
		free_matrices = matrices, active = {}, dead = dok and dead or {}, dead_names = dok and dead_names or {}, max = FIRE_MAX,
		flames = flames,
		-- a flame kind picked at random among the flame looks; other kinds stay as they are
		pick = function(key)
			if key ~= 'flame' or #flames < 2 then return key end
			return flames[math.random(#flames)]
		end,
		-- size of a fire point (times the kind's scale) from the tree's bounding sphere radius (about 20 m for a full
		-- tree), +-15 % at random; shrubs may go smaller than trees
		size = function(radius, shrub)
			local r = (type(radius) == 'number' and radius == radius) and radius or 20
			return math.min(1.3, math.max(shrub and 0.5 or 0.7, r / 20)) * (0.85 + 0.3 * math.random())
		end,
	}
end

-- stops a player's effects (reset to the scene's start) and puts it back in its pool
local function fire_release(point)
	if point.player then
		local holder = mr.read_pointer(point.player, 8)
		if not is_null(holder) then
			pcall(mr.call, fire.reset_at, 'void(pointer, pointer, uint8)', point.player, mr.read_pointer(holder, 0), 1)
		end
		local kind = fire.kinds[point.kind]
		if kind then kind.pool[#kind.pool + 1] = point.player end
		point.player = nil
	end
	if point.matrix then
		fire.free_matrices[#fire.free_matrices + 1] = point.matrix
		point.matrix = nil
	end
end

-- an engine call failed or the script stops: every fire point is stopped first (a scene whose draws stop keeps
-- burning), then fire is off for the battle
local sound = {} -- the sound emitter functions (v2.2), defined after fire_player

local function fire_fail(why, err)
	if not fire then return end
	for _, b in ipairs(fire.active) do pcall(fire_release, b) end
	pcall(sound.stop_all)
	fire = nil
	dbg('fire_off', why, err)
end

-- a scene player of a kind, from its pool or new; nil (and fire off) when the engine does not give one with a scene
local function fire_player(kind)
	local p = table.remove(kind.pool)
	if p then return p end
	local ok, player = pcall(mr.call, fire.create_at, 'pointer(pointer, pointer, uint8)', fire.cache, kind.buffer, 1)
	if not ok or is_null(player) or mr.tostring(mr.read_pointer(player, 0)) ~= fire.player_vtable
		or is_null(mr.read_pointer(player, 8)) then
		fire_fail('scene player', ok and 'the engine gave no scene player with a scene' or tostring(player))
		return nil
	end
	if not fire.draw_at then fire.draw_at = mr.read_pointer(mr.read_pointer(player, 0), 8) end
	return player
end


-- sound emitters (v2.2). The fire scenes are silent copies; the fire sound plays from at most SOUND.max emitters, each on
-- the busiest group of burning points near the camera. An emitter that is no longer needed is reset, which stops its
-- sound (run 28), and its scene player goes back to the pool.
function sound.off(em)
	if em.player then
		local holder = mr.read_pointer(em.player, 8)
		if not is_null(holder) then
			pcall(mr.call, fire.reset_at, 'void(pointer, pointer, uint8)', em.player, mr.read_pointer(holder, 0), 1)
		end
		local kind = fire.kinds.sound
		if kind then kind.pool[#kind.pool + 1] = em.player end
		em.player = nil
	end
	if em.matrix then
		fire.sound.matrices[#fire.sound.matrices + 1] = em.matrix
		em.matrix = nil
	end
end

function sound.stop_all()
	if not fire or not fire.sound then return end
	for _, em in ipairs(fire.sound.emitters) do pcall(sound.off, em) end
	fire.sound.emitters = {}
end

-- the sound goes quiet for the rest of the battle (the flames stay, silent)
function sound.fail(why, err)
	pcall(sound.stop_all)
	if fire then fire.sound = nil end
	dbg('sound_off', why, err)
end

function sound.player()
	local kind = fire.kinds.sound
	local p = table.remove(kind.pool)
	if p then return p end
	local ok, player = pcall(mr.call, fire.create_at, 'pointer(pointer, pointer, uint8)', fire.cache, kind.buffer, 1)
	if not ok or is_null(player) or mr.tostring(mr.read_pointer(player, 0)) ~= fire.player_vtable
		or is_null(mr.read_pointer(player, 8)) then
		return nil, ok and 'the engine gave no scene player with a scene' or tostring(player)
	end
	if not fire.draw_at then fire.draw_at = mr.read_pointer(mr.read_pointer(player, 0), 8) end
	return player
end

-- once a second: burning points in SOUND.cell cells, scored by count and nearness to the camera target; the best
-- SOUND.max cells get an emitter. An emitter keeps the nearest wanted cell; emitters left over are reset.
function sound.place()
	local snd = fire.sound
	local cells, order = {}, {}
	for _, b in ipairs(fire.active) do
		if b.player and b.kind ~= 'sound' then
			local key = math.floor(b.x / SOUND.cell) * 100000 + math.floor(b.z / SOUND.cell)
			local c = cells[key]
			if not c then
				c = { n = 0, x = 0, y = 0, z = 0 }
				cells[key] = c
				order[#order + 1] = c
			end
			c.n = c.n + 1
			c.x, c.y, c.z = c.x + b.x, c.y + b.y, c.z + b.z
		end
	end
	local cx, cz = nil, nil
	local cok, target = pcall(function() return bm:camera():target() end)
	if cok and target then cx, cz = target:get_x(), target:get_z() end
	for _, c in ipairs(order) do
		c.x, c.y, c.z = c.x / c.n, c.y / c.n, c.z / c.n
		local d = cx and math.sqrt((c.x - cx) ^ 2 + (c.z - cz) ^ 2) or 0
		c.score = c.n / (1 + (d / SOUND.distance) ^ 2)
	end
	table.sort(order, function(a, b) return a.score > b.score end)
	local want = math.min(SOUND.max, #order)
	local keep = {}
	for _, em in ipairs(snd.emitters) do
		local best, bd = nil, nil
		for i = 1, want do
			local c = order[i]
			if not c.em then
				local d = (c.x - em.tx) ^ 2 + (c.z - em.tz) ^ 2
				if not bd or d < bd then best, bd = c, d end
			end
		end
		if best then
			best.em = em
			em.tx, em.ty, em.tz = best.x, best.y, best.z
			keep[#keep + 1] = em
		else
			sound.off(em)
		end
	end
	for i = 1, want do
		local c = order[i]
		if not c.em then
			local player, why = sound.player()
			if not player then
				snd.emitters = keep
				sound.fail('sound player', why)
				return
			end
			local m = table.remove(snd.matrices) or mr.alloc(64)
			local em = { player = player, matrix = m, x = c.x, y = c.y, z = c.z, tx = c.x, ty = c.y, tz = c.z }
			c.em = em
			keep[#keep + 1] = em
		end
	end
	snd.emitters = keep
	if #keep > snd.most then snd.most = #keep end
	if debug_on then dbg('sound', #keep, #order, want) end
end

-- each frame while fires burn: the emitters glide towards their cells and are drawn (a scene plays only while drawn)
function sound.draw(dt)
	for _, em in ipairs(fire.sound.emitters) do
		if em.player then
			local dx, dy, dz = em.tx - em.x, em.ty - em.y, em.tz - em.z
			local d = math.sqrt(dx * dx + dy * dy + dz * dz)
			if d > SOUND.jump then
				em.x, em.y, em.z = em.tx, em.ty, em.tz
			elseif d > 0.01 then
				local step = math.min(1, SOUND.speed * dt / d)
				em.x, em.y, em.z = em.x + dx * step, em.y + dy * step, em.z + dz * step
			end
			mr.write(em.matrix, 0, floats_bytes({ 1, 0, 0, em.x, 0, 1, 0, em.y, 0, 0, 1, em.z, 0, 0, 0, 1 }))
			local ok, err = pcall(mr.call, fire.draw_at, DRAW_SIGNATURE, em.player, dt, em.matrix, nil, 1.0, 1, 1, 0, 0)
			if not ok then
				sound.fail('sound draw call', err)
				return
			end
		end
	end
end

local function bucket_key(bx, bz) return bx * 100000 + bz end

local function set_up_trees()
	local owner0 = mr.read_pointer(body_buffer, 0)
	if is_null(owner0) then return nil, 'no body owner yet' end
	local world = mr.read_pointer(owner0, 0x58)
	local display = mr.read_pointer(mr.read_pointer(world, 0x64600), 0x1d0)
	if mr.tostring(mr.read_pointer(display, 0x10)) ~= mr.tostring(world) then return nil, 'the drawn trees belong to another world' end
	local t = { instance_count = u32(display, 0x54), instances = mr.read_pointer(display, 0x58), list = {}, buckets = {},
		models = {} }
	local registry = mr.read_pointer(mr.read_pointer(world, 0x440), 0x150)
	t.owner_count = u32(registry, 0x164)
	t.owner_array = mr.read_pointer(registry, 0x168)
	t.index_map = mr.read_pointer(registry, 0x178)
	local container = mr.read_pointer(mr.read_pointer(world, 0x64540), 0xf0)
	local sentinel = mr.tostring(mr.add(container, 0x78))
	local entry = mr.read_pointer(container, 0x80)
	local total, models = 0, 0
	t.kinds = { tree = 0, shrub = 0, rock = 0, stump = 0 }
	while not is_null(entry) and mr.tostring(entry) ~= sentinel and models < MAX_MODELS do
		models = models + 1
		local count = u32(entry, 0x24)
		local nok, name = pcall(c_text, mr.read_pointer(entry, 0x18))
		local kind = (nok and name) and entry_kind(name) or 'tree'
		t.kinds[kind] = t.kinds[kind] + count
		t.models[#t.models + 1] = { name = (nok and name) or '?', kind = kind, count = count } -- for the debug submod
		local data = mr.read(mr.read_pointer(entry, 0x28), 0, count * 0x12)
		for k = 0, count - 1 do
			local tree = { number = total + k, x = f32(data, k * 0x12 + 1), z = f32(data, k * 0x12 + 9), scale = f32(data, k * 0x12 + 13),
				kind = kind }
			t.list[#t.list + 1] = tree
			local key = bucket_key(math.floor(tree.x / BUCKET), math.floor(tree.z / BUCKET))
			local b = t.buckets[key]
			if not b then b = {}; t.buckets[key] = b end
			b[#b + 1] = tree
		end
		total = total + count
		entry = mr.read_pointer(entry, 8)
	end
	-- one drawn tree per record, or the layout is not the one this script knows
	if total == 0 or total ~= t.instance_count then
		return nil, ('%d tree records, %d drawn trees'):format(total, t.instance_count)
	end
	return t
end

local function drop_tree(instance)
	for _, off in ipairs(Y_FIELDS) do
		mr.write(instance, off, float_at(instance, off) - DROP)
	end
end

-- 3x4 matrix (row-major, translation in column 4): rotation part replaced by R * rotation part
local function rotated_matrix(m, r)
	local out = {}
	for i = 0, 2 do
		for j = 0, 2 do
			out[i * 4 + j + 1] = r[i * 3 + 1] * m[j + 1] + r[i * 3 + 2] * m[4 + j + 1] + r[i * 3 + 3] * m[8 + j + 1]
		end
		out[i * 4 + 4] = m[i * 4 + 4]
	end
	return out
end

-- rotation about the horizontal unit axis (kx, 0, kz) by angle a
local function rotation(kx, kz, a)
	local c, s = math.cos(a), math.sin(a)
	local t = 1 - c
	return {
		c + t * kx * kx, -s * kz, t * kx * kz,
		s * kz, c, -s * kx,
		t * kx * kz, s * kx, c + t * kz * kz,
	}
end

-- pose: turned by angle a about the trunk base, moved dy metres up (negative = into the ground)
local function fall_pose(f, a, dy)
	dy = dy or 0
	local r = rotation(f.kx, f.kz, a)
	local m1, m2 = rotated_matrix(f.m1, r), rotated_matrix(f.m2, r)
	local c = f.crown or 1
	if c < 1 then
		-- thinner crown: the model's two horizontal axes (matrix columns 1 and 3) get shorter, its up axis keeps its length
		for i = 0, 2 do
			m1[i * 4 + 1] = m1[i * 4 + 1] * c; m1[i * 4 + 3] = m1[i * 4 + 3] * c
			m2[i * 4 + 1] = m2[i * 4 + 1] * c; m2[i * 4 + 3] = m2[i * 4 + 3] * c
		end
	end
	m1[8] = m1[8] + dy
	m2[8] = m2[8] + dy
	mr.write(f.instance, 0x30, floats_bytes(m1))
	mr.write(f.instance, 0x60, floats_bytes(m2))
	local px, py, pz = f.m1[4], f.m1[8], f.m1[12]
	local cx, cy, cz = f.sphere[1] - px, f.sphere[2] - py, f.sphere[3] - pz
	local nx = px + r[1] * cx + r[2] * cy + r[3] * cz
	local ny = py + r[4] * cx + r[5] * cy + r[6] * cz
	local nz = pz + r[7] * cx + r[8] * cy + r[9] * cz
	ny = ny + dy
	local rad = f.sphere[4]
	mr.write(f.instance, 0x08, floats_bytes({ nx, ny, nz, rad, nx - rad, ny - rad, nz - rad, nx + rad, ny + rad, nz + rad }))
end

-- the unit vector a tree falls or leans along: away from (x, z); turned to the blast's travel direction when it is known
-- (trees near the centre fall along it, trees at the edge also away from the centre)
local function fall_direction(tree, x, z)
	local dx, dz = tree.x - x, tree.z - z
	local d = math.sqrt(dx * dx + dz * dz)
	if blast_dir and blast_dir.vx then
		local w = DIR_EDGE_WEIGHT * math.min(1, d / math.max(blast_dir.radius, 1))
		if d > 0.01 then dx, dz = blast_dir.vx + dx / d * w, blast_dir.vz + dz / d * w
		else dx, dz = blast_dir.vx, blast_dir.vz end
		d = math.sqrt(dx * dx + dz * dz)
	end
	if d < 0.01 then
		local a = math.random() * 2 * math.pi
		return math.cos(a), math.sin(a)
	end
	return dx / d, dz / d
end

-- collision off at once; the drawn tree starts to fall away from (x, z)
-- parts: fire points along the lying tree (parts of its length), FIRE_POINTS when nil
local function fell_tree(tree, x, z, flaming, parts)
	tree.felled = true
	if tree.lean then tree.lean.cancelled = true; tree.lean = nil end
	local owner_number = u32(trees.index_map, tree.number * 4)
	if owner_number < trees.owner_count then
		local owner = mr.read_pointer(trees.owner_array, owner_number * 8)
		local flag = mr.read(owner, 0x68, 1):byte(1)
		if flag % 2 == 1 then mr.write(owner, 0x68, mr.uint8(flag - 1)) end
	end
	local instance = mr.add(trees.instances, tree.number * 0x98)
	local bytes = mr.read(instance, 0, 0x98)
	local dx, dz = fall_direction(tree, x, z)
	local m1 = floats_at(bytes, 0x30 + 1, 12)
	-- the trunk may already lean towards the fall direction: turn only as far as REST_ANGLE from vertical
	local lean = atan2(m1[2] * dx + m1[10] * dz, m1[6])
	local f = {
		tree = tree, instance = instance, start = tick, kx = dz, kz = -dx,
		angle = math.max(0.3, math.min(2.2, REST_ANGLE - lean)),
		m1 = m1, m2 = floats_at(bytes, 0x60 + 1, 12), sphere = floats_at(bytes, 0x08 + 1, 4),
	}
	local burns = fire and flaming and tree.kind ~= 'rock' and tree.kind ~= 'stump'
	if tree.kind == 'shrub' then
		-- a shrub does not tip over: it stays in place (burning in place when it burns), then sinks. Shrubs are many and
		-- small: they move once per tick (update_falls), not every frame
		f.shrub = true
		f.angle, f.fall_t = 0, 0
		f.lie_t = burns and SHRUB_BURN or SHRUB_LIE
	end
	falling[#falling + 1] = f
	-- flames tied to this tree while it burned standing (Wildfire): they move with the tree as it falls and shrink to
	-- nothing, then go out, so no flame stays in the air where the crown was (v2.2). A shrub does not fall: they go out.
	-- A tied flame stands on the trunk: it keeps its height above the drawn base and turns with the trunk.
	if tree.flames then
		local follow_extra = 0.1 -- seconds after the fall that a tied flame goes out
		local fall_t = f.fall_t or FALL_TIME
		for _, e in ipairs(tree.flames) do
			local t = (tick - e.fall.start) * TICK_MS / 1000
			if fire and fall_t > 0 and not e.skip and t < e.to then
				e.follow = f
				-- v2.3: a flame may sit up to about 1 m beside the trunk (Wildfire's flames up the tree); the offset
				-- turns with the tree. Larger offsets (record and drawn position apart) fall back to the trunk axis.
				local ox, oz = e.x - f.m1[4], e.z - f.m1[12]
				if ox * ox + oz * oz > 4 then ox, oz = 0, 0 end
				e.ox, e.oy, e.oz = ox, e.y - f.m1[8], oz
				e.to = t + fall_t + follow_extra
			else
				e.to = 0
			end
		end
		tree.flames = nil
	end
	if burns then
		-- fire points on the line of the lying tree: base + the base-to-centre offset (half the tree), turned by the fall
		local r = rotation(f.kx, f.kz, f.angle)
		local px, py, pz = f.m1[4], f.m1[8], f.m1[12]
		local cx, cy, cz = f.sphere[1] - px, f.sphere[2] - py, f.sphere[3] - pz
		local ox, oy, oz = r[1] * cx + r[2] * cy + r[3] * cz, r[4] * cx + r[5] * cy + r[6] * cz, r[7] * cx + r[8] * cy + r[9] * cz
		f.burn = true
		local shrub = tree.kind == 'shrub'
		if #fire.dead > 0 and not shrub then f.dead_model = fire.dead[tree.number % #fire.dead + 1] end
		for _, stage in ipairs(shrub and SHRUB_STAGES or FIRE_STAGES) do
			if fire.kinds[stage[1]] then
				for _, part in ipairs(parts or (shrub and SHRUB_POINTS) or fire_points) do
					local k = 2 * part
					fire.active[#fire.active + 1] = {
						fall = f, kind = fire.pick(stage[1]), from = stage[2], to = stage[3], scale = -1,
						x = px + ox * k, y = py + math.max(0, oy * k), z = pz + oz * k, size = fire.size(f.sphere[4], shrub),
					}
				end
			end
		end
		for _, fn in ipairs(burn_listeners) do pcall(fn, tree, x, z) end
	end
	if debug_on then dbg('fell', tree, cause, flaming, burns, f.angle) end
end

-- a hit that leaves the tree standing: lean it by angle a away from (x, z), over LEAN_TIME
local function lean_tree(tree, x, z, a)
	if tree.lean then tree.lean.cancelled = true end
	local instance = mr.add(trees.instances, tree.number * 0x98)
	local bytes = mr.read(instance, 0, 0x98)
	local dx, dz = fall_direction(tree, x, z)
	local f = {
		lean = true, tree = tree, instance = instance, start = tick, kx = dz, kz = -dx, angle = a,
		m1 = floats_at(bytes, 0x30 + 1, 12), m2 = floats_at(bytes, 0x60 + 1, 12), sphere = floats_at(bytes, 0x08 + 1, 4),
	}
	tree.lean = f
	falling[#falling + 1] = f
end

-- takes points from a tree; fells it at 0, leans it otherwise
local function hit_tree(tree, x, z, points, flaming)
	if not tree.hp then
		if tree.kind == 'shrub' then tree.hp = 1
		else tree.hp = HP_BASE + ((tree.scale or 0) > BIG_TREE_SCALE and HP_BIG_TREE or 0) end
	end
	tree.hp = tree.hp - points
	if tree.hp <= 0 then
		fell_tree(tree, x, z, flaming)
	else
		lean_tree(tree, x, z, LEAN_PER_POINT * points)
		if debug_on then dbg('lean', tree, cause, points) end
	end
end

-- shrubs take part only while fire is on: with Fire Off (CFG.fire false) blasts, vortexes and monsters leave them alone,
-- as plain scenery (user, 2026-10-18)
local function in_play(tree)
	return tree.kind ~= 'shrub' or CFG.fire
end

-- hits every standing tree within radius of (x, z). vortex = true: 1 point, at most once per VORTEX_HIT_SECONDS a tree
local function hit_around(x, z, radius, vortex, flaming)
	local r2 = radius * radius
	local big = radius >= HP_BIG_RADIUS
	local vortex_ticks = math.floor(VORTEX_HIT_SECONDS * 1000 / TICK_MS + 0.5)
	for bx = math.floor((x - radius) / BUCKET), math.floor((x + radius) / BUCKET) do
		for bz = math.floor((z - radius) / BUCKET), math.floor((z + radius) / BUCKET) do
			local b = trees.buckets[bucket_key(bx, bz)]
			if b then
				for _, tree in ipairs(b) do
					if not tree.felled and in_play(tree) then
						local dx, dz = tree.x - x, tree.z - z
						local d2 = dx * dx + dz * dz
						if d2 <= r2 then
							if big then
								fell_tree(tree, x, z, flaming)
							elseif vortex then
								if not tree.vortex_tick or tick - tree.vortex_tick >= vortex_ticks then
									tree.vortex_tick = tick
									hit_tree(tree, x, z, 1, flaming)
								end
							else
								hit_tree(tree, x, z, d2 * 4 <= r2 and 2 or 1, flaming)
							end
						end
					end
				end
			end
		end
	end
end

-- the effect object's own blast radius, or nil when the object does not look like a live area effect
local function object_radius(object)
	local vt = mr.tostring(mr.read_pointer(object, 0))
	if vt < EFFECT_VTABLE_LOW or vt > EFFECT_VTABLE_HIGH then return nil, vt end
	local r = float_at(object, OBJECT_RADIUS)
	if r ~= r or r < MIN_RADIUS or r > MAX_RADIUS then return nil, vt end
	return r, vt
end

-- the blast's ignition amount, read from memory as its class's getter (vtable slot 14) would; nil when not known
local function object_ignition(object)
	local fn = mr.read_pointer(mr.read_pointer(object, 0), IGNITION_SLOT)
	local at = mr.tostring(fn)
	if at < CODE_LOW or at > CODE_HIGH then return nil end
	local b = mr.read(fn, 0, 13)
	local A, B
	if b:byte(1) == 0x48 and b:byte(2) == 0x8B and b:byte(3) == 0x81 and b:byte(7) == 0 and b:byte(8) == 0xF3
		and b:byte(9) == 0x0F and b:byte(10) == 0x10 and b:byte(11) == 0x40 and b:byte(13) == 0xC3 then
		A = b:byte(4) + b:byte(5) * 256 + b:byte(6) * 65536
		B = b:byte(12)
	elseif b:byte(1) == 0xF3 and b:byte(2) == 0x0F and b:byte(3) == 0x10 and b:byte(4) == 0x81 and b:byte(9) == 0xC3 then
		A, B = EXPLOSION_RECORD, EXPLOSION_IGNITION
	else
		return nil
	end
	if A > 0x1000 then return nil end
	local record = mr.read_pointer(object, A)
	if is_null(record) then return nil end
	local v = float_at(record, B)
	if v ~= v or v < 0 or v > 1000 then return nil end
	return v
end

local function test_log(text)
	local file = io.open(TEST_LOG, 'a')
	if file then file:write(text, '\n'); file:close() end
end

local function handle_impact(slot, object)
	local x, z = f32(slot, 1), f32(slot, 9)
	local radius = math.max(f32(slot, 13), MIN_RADIUS)
	local ok, r, vt = false, nil, nil
	if not is_null(object) then ok, r, vt = pcall(object_radius, object) end
	if ok and r then radius = r end
	-- flaming only when the ignition can be read from a known area effect and is above 0
	local ignition = nil
	if ok and r then
		local iok, v = pcall(object_ignition, object)
		if iok then ignition = v end
	end
	local flaming = (ignition or 0) > 0
	if test_mode then
		test_log(('t=%.1f blast (%.1f, %.1f) vtable %s radius %.2f ignition %s -> %s'):format(
			tick * TICK_MS / 1000, x, z, tostring(vt), radius, tostring(ignition), flaming and 'FLAMING' or 'force'))
	end
	-- the projectile's flight direction, from the explosion record at the same spot (newest first)
	-- the nearest recorded shell whose flight line passes through the impact
	local vx, vz, best = nil, nil, nil
	for _, e in ipairs(dirs) do
		if e.vx then
			local dx, dz = x - e.x, z - e.z
			local along, side = dx * e.vx + dz * e.vz, math.abs(dx * e.vz - dz * e.vx)
			local d = dx * dx + dz * dz
			if side < DIR_MATCH and math.abs(along) < e.speed * DIR_AHEAD + DIR_MATCH and (not best or d < best) then
				vx, vz, best = e.vx, e.vz, d
			end
		end
	end
	if test_mode then test_log(('    flight %s'):format(vx and ('%.2f %.2f'):format(vx, vz) or 'unknown')) end
	blast_dir = { radius = radius, vx = vx, vz = vz }
	local c = debug_on and { by = 'blast' } or nil
	cause = c
	hit_around(x, z, radius, false, flaming)
	cause = nil
	blast_dir = nil
	if c then dbg('blast', c, x, z, radius, flaming, ok and r ~= nil, vt and tostring(vt) or nil, ignition, vx, vz) end
	if CFG.vortex and ok and vt and #watched < MAX_WATCH then
		watched[#watched + 1] = { object = object, vt = vt, born = tick, x = x, z = z, lx = x, lz = z, radius = radius,
			moved = false, flaming = flaming }
	end
end

-- follows effects that move (vortexes) and fells the trees around each new position
local function update_watched()
	local keep = {}
	for _, w in ipairs(watched) do
		local age = (tick - w.born) * TICK_MS / 1000
		local ok, vt, pos = pcall(function()
			return mr.tostring(mr.read_pointer(w.object, 0)), mr.read(w.object, 0x60, 0x18)
		end)
		local ended = not ok or vt ~= w.vt
		if not ended then
			-- the constructor writes the start position to + 0x60 and + 0x6c; take the copy that moved more
			local ax, az = f32(pos, 13), f32(pos, 21)
			local bx, bz = f32(pos, 1), f32(pos, 9)
			local cx, cz = ax, az
			if (bx - w.x) ^ 2 + (bz - w.z) ^ 2 > (ax - w.x) ^ 2 + (az - w.z) ^ 2 then cx, cz = bx, bz end
			local step = math.sqrt((cx - w.lx) ^ 2 + (cz - w.lz) ^ 2)
			if step > MOVE_MAX then
				ended = true
				if debug_on then dbg('vortex_jump', w, step, w.moved) end
			elseif step > MOVE_MIN then
				if not w.moved and debug_on then dbg('vortex', w, w.x, w.z, w.radius, w.flaming, w.vt) end
				w.moved = true
				local sl = math.sqrt((cx - w.lx) ^ 2 + (cz - w.lz) ^ 2)
				blast_dir = { radius = w.radius, vx = (cx - w.lx) / sl, vz = (cz - w.lz) / sl }
				cause = debug_on and { by = 'vortex', vortex = w } or nil
				hit_around(cx, cz, w.radius, true, w.flaming)
				cause = nil
				blast_dir = nil
				w.lx, w.lz = cx, cz
			end
			if age > FOLLOW_SECONDS or (not w.moved and age > WATCH_SECONDS) then ended = true end
		end
		if not ended then keep[#keep + 1] = w elseif w.moved and debug_on then dbg('vortex_end', w, age) end
	end
	watched = keep
end

local function fall_time(f)
	local since = math.min(math.max(os.clock() - last_tick_clock, 0), TICK_MS / 1000)
	return (tick - f.start) * TICK_MS / 1000 + since
end

-- the tree's pose at time t since the blast: tipping over, lying (no change), sinking
local function crown_at(f, t)
	if not f.burn then return 1 end
	local fall_t, lie_t = f.fall_t or FALL_TIME, f.lie_t or LIE_TIME
	local u = (t - fall_t - CROWN_BURN_START) / math.max(0.1, lie_t - CROWN_BURN_START)
	return 1 - (1 - crown_min) * math.min(1, math.max(0, u))
end

-- an upright entry (a shrub that does not burn: angle 0, full crown) moved dy metres up: only its five height fields
-- change, with the values fall_pose(f, 0, dy) would write
local function sink_upright(f, dy)
	local py = f.m1[8]
	local ny = py + (f.sphere[2] - py) + dy
	local rad = f.sphere[4]
	mr.write(f.instance, 0x0C, f32_bytes(ny))
	mr.write(f.instance, 0x1C, f32_bytes(ny - rad))
	mr.write(f.instance, 0x28, f32_bytes(ny + rad))
	mr.write(f.instance, 0x4C, f32_bytes(f.m1[8] + dy))
	mr.write(f.instance, 0x7C, f32_bytes(f.m2[8] + dy))
end

local function pose_at(f, t)
	f.crown = crown_at(f, t)
	local fall_t, lie_t = f.fall_t or FALL_TIME, f.lie_t or LIE_TIME
	if f.lean then
		local u = math.min(1, t / LEAN_TIME)
		fall_pose(f, f.angle * (1 - (1 - u) * (1 - u)))
	elseif t < fall_t then
		local u = t / fall_t
		fall_pose(f, f.angle * u * u)
	elseif t >= fall_t + lie_t then
		local u = math.min(1, (t - fall_t - lie_t) / SINK_TIME)
		if f.shrub and not f.burn then sink_upright(f, -SINK_DEPTH * u * u)
		else fall_pose(f, f.angle, -SINK_DEPTH * u * u) end
	elseif f.burn then
		fall_pose(f, f.angle)
	end
end

-- each UI update: draw the fire points of felled trees. Fire time follows battle time, so it stops while paused.
local function draw_fires()
	local since = math.min(math.max(os.clock() - last_tick_clock, 0), TICK_MS / 1000)
	local now = tick * TICK_MS / 1000 + since
	local dt = fire_clock and math.min(math.max(now - fire_clock, 0), FIRE_MAX_DT) or 0
	fire_clock = now
	local keep = {}
	local drew = false -- a fire point drew this frame (the sound emitters play only then)
	for _, b in ipairs(fire.active) do
		local t = (tick - b.fall.start) * TICK_MS / 1000
		if t >= b.to then
			fire_release(b)
		else
			if t >= b.from and not b.skip then
				local kind = fire.kinds[b.kind]
				if not b.player then
					b.matrix = table.remove(fire.free_matrices)
					if not b.matrix then
						-- FIRE_MAX points burn already: wait; a flame that cannot start soon is dropped
						if kind.flame and t > b.from + FLAME_WAIT then b.skip = true end
						if b.skip and debug_on then dbg('flame_dropped', b.kind) end
					else
						b.player = fire_player(kind)
						if not fire then return end
					end
				end
				if b.player then
					local full = kind.scale * (b.size or 1)
					local scale = full
					local moved = false
					if b.follow then
						-- a tied flame on a falling tree: turned about the trunk base as the tree is, shrinking to nothing
						local f = b.follow
						local u = math.min(1, fall_time(f) / (f.fall_t or FALL_TIME))
						local r = rotation(f.kx, f.kz, f.angle * u * u)
						local ox, oy, oz = b.ox, b.oy, b.oz
						b.x = f.m1[4] + r[1] * ox + r[2] * oy + r[3] * oz
						b.y = f.m1[8] + r[4] * ox + r[5] * oy + r[6] * oz
						b.z = f.m1[12] + r[7] * ox + r[8] * oy + r[9] * oz
						scale = full * math.max(0, 1 - u)
						moved = true
					else
						local sink_at = (b.fall.fall_t or FALL_TIME) + (b.fall.lie_t or LIE_TIME)
						if t > sink_at then
							scale = full * math.max(0, 1 - (t - sink_at) / SINK_TIME)
						end
					end
					if moved or math.abs(scale - b.scale) > 0.001 then
						b.scale = scale
						mr.write(b.matrix, 0, floats_bytes({ scale, 0, 0, b.x, 0, scale, 0, b.y, 0, 0, scale, b.z, 0, 0, 0, 1 }))
					end
					local ok, err = pcall(mr.call, fire.draw_at, DRAW_SIGNATURE, b.player, dt, b.matrix, nil, 1.0, 1, 1, 0, 0)
					if not ok then
						fire_fail('draw call', err)
						return
					end
					drew = true
				end
			end
			keep[#keep + 1] = b
		end
	end
	fire.active = keep
	if fire.sound then
		-- the last fire point went out: the sound stops now, not at the next placement
		if #keep == 0 then sound.stop_all() elseif drew then sound.draw(dt) end
	end
end

-- stops every burning fire point (battle over or fire switched off)
local function fire_stop_all()
	if not fire then return end
	for _, b in ipairs(fire.active) do pcall(fire_release, b) end
	fire.active = {}
	pcall(sound.stop_all)
end

-- each UI update: pose the trees that are tipping over or sinking
local function pose_falls()
	if fire and #fire.active > 0 then
		local ok, err = pcall(draw_fires)
		if not ok then pcall(fire_fail, 'draw_fires', err) end
	end
	for _, f in ipairs(falling) do
		if not f.cancelled and not f.shrub then
			local t = fall_time(f)
			local fall_t = f.fall_t or FALL_TIME
			if f.lean or f.burn or t < fall_t or t >= fall_t + (f.lie_t or LIE_TIME) then pose_at(f, t) end
		end
	end
end

-- each tick: lay trees down, let them sink, remove them after SINK_TIME
local function update_falls()
	local keep = {}
	for _, f in ipairs(falling) do
		local t = (tick - f.start) * TICK_MS / 1000
		if f.cancelled then
			-- a lean that a fall or a newer lean took over: drop it
		elseif f.lean then
			if t >= LEAN_TIME then
				fall_pose(f, f.angle)
				if f.tree.lean == f then f.tree.lean = nil end
				shadow_reset_wanted = true
			else
				pose_at(f, t)
				keep[#keep + 1] = f
			end
		elseif t >= (f.fall_t or FALL_TIME) + (f.lie_t or LIE_TIME) + SINK_TIME then
			drop_tree(f.instance)
			shadow_reset_wanted = true
			if debug_on and f.tree then dbg('removed', f.tree) end
		else
			if not f.down and t >= (f.fall_t or FALL_TIME) then
				fall_pose(f, f.angle)
				f.down = true
				shadow_reset_wanted = true
			else
				pose_at(f, t)
			end
			if f.dead_model and not f.swapped and t >= DEAD_SWAP then
				-- its leaves have burnt away: the tree becomes a dead tree model of the map
				f.swapped = true
				mr.write(f.instance, MODEL_FIELD, string.char(f.dead_model % 256, math.floor(f.dead_model / 256)))
				shadow_reset_wanted = true
				if debug_on and f.tree then dbg('dead', f.tree, f.dead_model) end
			end
			keep[#keep + 1] = f
		end
	end
	falling = keep
end

-- reads the projectile explosion records written since the last tick
local function read_dirs()
	local count = u24(mr.read(dir_buffer, 0, 4), 1)
	local new = (count - dir_last) % 16777216
	if new > DIR_SLOTS then
		dir_last = (count - DIR_SLOTS) % 16777216
		new = DIR_SLOTS
	end
	local keep = {}
	for _, e in ipairs(dirs) do if tick - e.tick <= 2 then keep[#keep + 1] = e end end
	for n = 0, new - 1 do
		local slot = mr.read(dir_buffer, 16 + ((dir_last + n) % DIR_SLOTS) * DIR_SLOT_BYTES, 20)
		local vx, vz = f32(slot, 9), f32(slot, 17)
		local l = math.sqrt(vx * vx + vz * vz)
		keep[#keep + 1] = { tick = tick, x = f32(slot, 1), z = f32(slot, 5), vx = l > 0.01 and vx / l or nil, vz = l > 0.01 and vz / l or nil, speed = l }
	end
	dir_last = count
	dirs = keep
end

-- the heavy units of this battle (rebuilt now and then: reinforcements, summons)
local function scan_heavy()
	local list = _G.altius_timber_heavy_units
	local old = heavy or {}
	heavy = {}
	if type(list) ~= 'table' then return end
	-- the same unit keeps its last swing and position (the lists come in the same order each time)
	local function add(h)
		local o = old[#heavy + 1]
		if o and o.key == h.key and o.walk == h.walk then h.swing, h.lx, h.lz = o.swing, o.lx, o.lz end
		heavy[#heavy + 1] = h
	end
	-- a setting that is not a number (nil, a wrong MCT value) means: no unit is that heavy
	local walk_mass, melee_mass = tonumber(CFG.walk_mass) or NEVER, tonumber(CFG.melee_mass) or NEVER
	local alliances = bm:alliances()
	for a = 1, alliances:count() do
		local armies = alliances:item(a):armies()
		for b = 1, armies:count() do
			local units = armies:item(b):units()
			for u = 1, units:count() do
				local unit = units:item(u)
				local key = unit:type()
				local e = list[key]
				if type(e) == 'table' and type(e[1]) == 'number' then
					local mass = type(e[2]) == 'number' and e[2] or LEGACY_TIER_MASS[e[2]] or 0
					if mass >= walk_mass then
						add({ unit = unit, key = key, radius = math.min(e[1], HEAVY_RADIUS_MAX), walk = true })
					elseif mass >= melee_mass then
						add({ unit = unit, key = key, radius = math.min(e[1], HEAVY_RADIUS_MAX), walk = false })
					end
				end
			end
		end
	end
	if debug_on then dbg('heavy_scan', heavy) end
end

-- fells (force) the trees within reach of (x, z); with a facing (fx, fz), only those in the cone in front of it
local function heavy_fell(unit, how, x, z, reach, fx, fz)
	for bx = math.floor((x - reach) / BUCKET), math.floor((x + reach) / BUCKET) do
		for bz = math.floor((z - reach) / BUCKET), math.floor((z + reach) / BUCKET) do
			local bucket = trees.buckets[bucket_key(bx, bz)]
			if bucket then
				for _, tree in ipairs(bucket) do
					local dx, dz = tree.x - x, tree.z - z
					local d2 = dx * dx + dz * dz
					if not tree.felled and in_play(tree) and d2 <= reach * reach
						and (not fx or (dx * fx + dz * fz) >= MELEE_CONE * math.sqrt(d2)) then
						if debug_on and not cause then
							cause = { by = how, unit = unit:type(), melee = unit:is_in_melee(), flying = unit:is_currently_flying() }
						end
						fell_tree(tree, x, z, false)
						if test_mode then
							test_log(('t=%.1f heavy %s %s fells tree %d'):format(tick * TICK_MS / 1000, how, unit:type(), tree.number))
						end
					end
				end
			end
		end
	end
	cause = nil
end

-- facing of a unit as a unit vector (x, z) from its bearing in degrees (0 = +z, 90 = +x)
local function facing(unit)
	local b = math.rad(unit:bearing())
	return math.sin(b), math.cos(b)
end

-- heavy units on the ground push over trees (force: no fire). Walk tier (mass walk_mass or more): the trees they walk
-- into, along their way. Melee tier (melee_mass up to walk_mass): while in melee, every MELEE_SWING_TICKS, the trees in
-- front of them, along their facing.
local function heavy_pass()
	if not heavy_scan_tick or tick - heavy_scan_tick >= HEAVY_RESCAN_TICKS then
		heavy_scan_tick = tick
		scan_heavy()
	end
	for _, h in ipairs(heavy) do
		local ok, err = pcall(function()
			local unit = h.unit
			if unit:number_of_men_alive() <= 0 or unit:is_currently_flying() then return end
			local p = unit:position()
			local x, z = p:get_x(), p:get_z()
			if h.walk then
				local vx, vz = nil, nil
				if h.lx then
					local sl = math.sqrt((x - h.lx) ^ 2 + (z - h.lz) ^ 2)
					if sl > 0.05 then vx, vz = (x - h.lx) / sl, (z - h.lz) / sl end
				end
				h.lx, h.lz = x, z
				local reach = h.radius + HEAVY_REACH
				blast_dir = { radius = reach, vx = vx, vz = vz }
				heavy_fell(unit, 'walk', x, z, reach)
			elseif unit:is_in_melee() then
				if h.swing and tick - h.swing < MELEE_SWING_TICKS then return end
				h.swing = tick
				local fx, fz = facing(unit)
				local reach = h.radius + MELEE_REACH
				blast_dir = { radius = reach, vx = fx, vz = fz }
				heavy_fell(unit, 'melee', x, z, reach, fx, fz)
			else
				h.swing = nil
			end
			blast_dir = nil
		end)
		if not ok then
			blast_dir = nil
			cause = nil
			if debug_on then dbg('error', 'heavy unit', err) end
		end
	end
end

-- a cannonball touched a trunk at (x, y, z): the nearest standing tree whose base is within SHOT_REACH falls, in one hit,
-- away from the cannon (the contact normal points back at it); a flaming ball (ignition above 0) sets it on fire
local function shot_hit(x, y, z, nx, nz, ignition, vx, vz)
	local best, best_d2 = nil, SHOT_REACH * SHOT_REACH
	for bx = math.floor((x - SHOT_REACH) / BUCKET), math.floor((x + SHOT_REACH) / BUCKET) do
		for bz = math.floor((z - SHOT_REACH) / BUCKET), math.floor((z + SHOT_REACH) / BUCKET) do
			local bucket = trees.buckets[bucket_key(bx, bz)]
			if bucket then
				for _, tree in ipairs(bucket) do
					if not tree.felled and in_play(tree) then
						local d2 = (tree.x - x) ^ 2 + (tree.z - z) ^ 2
						if d2 <= best_d2 then best, best_d2 = tree, d2 end
					end
				end
			end
		end
	end
	local flaming = (ignition or 0) > 0 and ignition == ignition
	local c = debug_on and { by = 'shot' } or nil
	if best then
		local l = math.sqrt(nx * nx + nz * nz)
		blast_dir = { radius = SHOT_REACH, vx = l > 0.01 and -nx / l or nil, vz = l > 0.01 and -nz / l or nil }
		cause = c
		fell_tree(best, x, z, flaming)
		cause = nil
		blast_dir = nil
		shot_fells = shot_fells + 1
	end
	if test_mode then
		test_log(('t=%.1f shot (%.1f, %.1f, %.1f) normal %.2f %.2f ignition %.2f -> %s'):format(tick * TICK_MS / 1000, x, y, z,
			nx, nz, ignition or 0, best and ('fells %s %d at %.2f m%s'):format(best.kind or 'tree', best.number,
			math.sqrt(best_d2), flaming and ', flaming' or '') or 'no tree within reach'))
	end
	if c then dbg('shot', c, x, y, z, nx, nz, flaming, best, best and math.sqrt(best_d2) or nil) end
end

-- the contacts cave 4 stored since the last tick
local function read_shots()
	local count = u24(mr.read(shot_buffer, 0, 4), 1)
	local new = (count - shot_last) % 16777216
	if new > SHOT_SLOTS then
		shot_lost = shot_lost + new - SHOT_SLOTS
		shot_last = (count - SHOT_SLOTS) % 16777216
		new = SHOT_SLOTS
	end
	for n = 0, new - 1 do
		local slot = mr.read(shot_buffer, 16 + ((shot_last + n) % SHOT_SLOTS) * SHOT_SLOT_BYTES, SHOT_SLOT_BYTES)
		shot_count = shot_count + 1
		local ok, err = pcall(shot_hit, f32(slot, 1), f32(slot, 5), f32(slot, 9), f32(slot, 13), f32(slot, 17), f32(slot, 21),
			f32(slot, 25), f32(slot, 29))
		cause = nil
		blast_dir = nil
		if not ok and debug_on then dbg('error', 'shot_hit', err) end
	end
	shot_last = count
end

local function on_tick()
	tick = tick + 1
	last_tick_clock = os.clock()
	debug_on = type(_G.altius_timber_debug) == 'table'
	local body_calls = u24(mr.read(body_buffer, 8, 4), 1)
	body_calls_this_battle = body_calls_this_battle + (body_calls - body_last) % 16777216
	body_last = body_calls
	if not trees then
		-- until the body cave runs in this battle, its buffer holds an owner of an earlier battle
		if body_calls_this_battle == 0 then return end
		local ok, result, why = pcall(set_up_trees)
		if not ok or not result then
			stopped = true
			dbg('stop', 'trees not read', ok and why or tostring(result))
			return
		end
		trees = result
		if debug_on then dbg('trees', trees) end
		if test_mode then
			test_log(('trees read: %d entries: tree %d, shrub %d, rock %d, stump %d'):format(#trees.list, trees.kinds.tree,
				trees.kinds.shrub, trees.kinds.rock, trees.kinds.stump))
		end
		local world = mr.read_pointer(mr.read_pointer(body_buffer, 0), 0x58)
		fire_world = world
		if CFG.fire then
			local fok, f, fwhy = pcall(fire_setup, world)
			fire = fok and f or nil
			if debug_on then dbg('fire', fire, fok and fwhy or tostring(f)) end
		else
			fire = nil
			if debug_on then dbg('fire', nil, 'fire is off in the settings') end
		end
	end
	if dir_buffer then
		local dok, derr = pcall(read_dirs)
		if not dok and debug_on then dbg('error', 'read_dirs', derr) end
	end
	local count = u24(mr.read(impact_buffer, 0, 4), 1)
	local new = (count - impact_last) % 16777216
	if new > RING_SLOTS then
		impact_last = (count - RING_SLOTS) % 16777216
		new = RING_SLOTS
	end
	for n = 0, new - 1 do
		local index = (impact_last + n) % RING_SLOTS
		local slot = mr.read(impact_buffer, 16 + index * SLOT_BYTES, SLOT_BYTES)
		local object = mr.read_pointer(impact_buffer, 16 + index * SLOT_BYTES + 0x20)
		local hok, herr = pcall(handle_impact, slot, object)
		cause = nil
		if not hok and debug_on then dbg('error', 'handle_impact', herr) end
	end
	impact_last = count
	if shot_buffer then
		local tok, terr = pcall(read_shots)
		if not tok and debug_on then dbg('error', 'read_shots', terr) end
	end
	local sok, serr = pcall(update_watched)
	cause = nil
	if not sok and debug_on then dbg('error', 'update_watched', serr) end
	sok, serr = pcall(heavy_pass)
	cause = nil
	if not sok and debug_on then dbg('error', 'heavy_pass', serr) end
	sok, serr = pcall(update_falls)
	if not sok and debug_on then dbg('error', 'update_falls', serr) end
	-- fire sound (v2.2): the emitters follow the busiest burning cells near the camera, once a second
	if fire and fire.sound and tick >= fire.sound.next_tick then
		fire.sound.next_tick = tick + SOUND.ticks
		local pok, perr = pcall(sound.place)
		if not pok then pcall(sound.fail, 'place_sound', perr) end
	end
	if shadow_reset_wanted then
		shadow_reset_wanted = false
		reset_shadows()
		reset_again_tick = tick + math.floor(SHADOW_RESET_AGAIN_MS / TICK_MS)
	elseif reset_again_tick and tick >= reset_again_tick then
		reset_shadows()
		reset_again_tick = nil
	end
end

-- hook for Wildfire and other add-ons. Tree tables are shared, read-only for an add-on: number, x, z (base), scale,
-- felled.
_G.altius_timber_api = {
	version = 8,
	-- 'tree', 'shrub', 'rock' or 'stump' (rocks and stumps never burn; shrubs sink instead of falling, burn shorter)
	kind = function(tree) return tree.kind or 'tree' end,
	-- entries of each kind in this battle's tree list (empty before set-up)
	kind_counts = function() return trees and trees.kinds or {} end,
	-- false once Timber! is switched off in the settings or stopped (a check failed): nothing will burn this battle
	enabled = function() return CFG.enable and not stopped end,
	-- a setting by its key (CFG / the MCT page), e.g. 'wf_chance'
	setting = function(key) return CFG[key] end,
	-- seconds a tree (or a shrub, kind 'shrub') burning on the ground holds its fire points after api.burn
	burn_hold = function(kind)
		if kind == 'shrub' then return SHRUB_BURN + 1.5 end
		return FALL_TIME + LIE_TIME + 1.5
	end,
	-- true once this battle's trees are read and fire scenes are available
	ready = function() return trees ~= nil and fire ~= nil and not stopped end,
	-- battle seconds (stops while paused)
	now = function() return tick * TICK_MS / 1000 end,
	-- every tree of the map, or nil before set-up
	trees = function() return trees and trees.list end,
	-- trees (standing or felled) with their base within r of (x, z)
	trees_near = function(x, z, r)
		local out = {}
		if not trees then return out end
		local r2 = r * r
		for bx = math.floor((x - r) / BUCKET), math.floor((x + r) / BUCKET) do
			for bz = math.floor((z - r) / BUCKET), math.floor((z + r) / BUCKET) do
				local b = trees.buckets[bucket_key(bx, bz)]
				if b then
					for _, tree in ipairs(b) do
						local dx, dz = tree.x - x, tree.z - z
						if dx * dx + dz * dz <= r2 then out[#out + 1] = tree end
					end
				end
			end
		end
		return out
	end,
	-- height of the tree's base as drawn (the record y is not used by the engine on every map); read once, while the
	-- tree stands or right after it is felled (a fall turns the tree about its base, a sink moves it down)
	base_y = function(tree)
		if not tree.base_y and trees then
			tree.base_y = float_at(mr.add(trees.instances, tree.number * 0x98), 0x4C)
		end
		return tree.base_y
	end,
	-- fire points not taken: FIRE_MAX minus the points drawing, waiting for a slot or queued to start later
	fire_room = function()
		if not fire then return 0 end
		local used = 0
		for _, b in ipairs(fire.active) do
			if not b.skip and (b.player or (tick - b.fall.start) * TICK_MS / 1000 < b.to) then used = used + 1 end
		end
		return fire.max - used
	end,
	-- fn(tree, x, z) is called when a felled tree starts to burn; (x, z) = what felled it
	on_burn = function(fn) burn_listeners[#burn_listeners + 1] = fn end,
	-- fells a standing tree away from (x, z) and burns it as a flaming blast would; true when done.
	-- parts: optional list of fire points along the lying tree (e.g. { 0.5 } = one point in the middle)
	burn = function(tree, x, z, parts)
		if not trees or not fire or stopped or tree.felled or tree.kind == 'rock' or tree.kind == 'stump' then return false end
		local saved, saved_cause = blast_dir, cause
		blast_dir = nil
		cause = debug_on and { by = 'api.burn' } or nil
		local ok, err = pcall(fell_tree, tree, x, z, true, parts)
		blast_dir, cause = saved, saved_cause
		if not ok and debug_on then dbg('error', 'api.burn', err) end
		return ok
	end,
	-- n more fire points for this battle (a submod that keeps many trees burning); the new total
	add_fire_points = function(n)
		if not fire then return 0 end
		for k = 1, n do fire.free_matrices[#fire.free_matrices + 1] = mr.alloc(64) end
		fire.max = fire.max + n
		return fire.max
	end,
	-- centre of a standing tree's bounding sphere (about half its height above the base)
	crown = function(tree)
		local c = floats_at(mr.read(mr.add(trees.instances, tree.number * 0x98), 0x08, 12), 1, 3)
		return c[1], c[2], c[3]
	end,
	-- a standing tree becomes a dead tree model of the map (leaves burnt away); false when the map has none
	char = function(tree)
		if not fire or not trees or #fire.dead == 0 or tree.felled or (tree.kind or 'tree') ~= 'tree' then return false end
		local dead = fire.dead[tree.number % #fire.dead + 1]
		mr.write(mr.add(trees.instances, tree.number * 0x98), MODEL_FIELD, string.char(dead % 256, math.floor(dead / 256)))
		shadow_reset_wanted = true
		return true
	end,
	-- a small flame at (x, y, z) for the given seconds; returns a handle for flame_stop, or false. With a tree (api v8) the
	-- flame is tied to it: when the tree is felled, the flame moves with it as it falls, shrinks to nothing and goes out
	flame_at = function(x, y, z, seconds, tree)
		if not fire or stopped or not fire.kinds.flame then return false end
		-- fall_t + lie_t = seconds: no sink fade (draw_fires shrinks the points of sinking trees), full size until the end
		-- v2.3: a random flame look; with a tree, the size follows its bounding sphere radius (instance + 0x14)
		local radius = nil
		if type(tree) == 'table' and trees and type(tree.number) == 'number' then
			local ok, r = pcall(function()
				return floats_at(mr.read(mr.add(trees.instances, tree.number * 0x98), 0x14, 4), 1, 1)[1]
			end)
			if ok then radius = r end
		end
		local e = { fall = { start = tick, fall_t = seconds, lie_t = 0 }, kind = fire.pick('flame'), from = 0, to = seconds,
			scale = -1, x = x, y = y, z = z, size = fire.size(radius, type(tree) == 'table' and tree.kind == 'shrub') }
		fire.active[#fire.active + 1] = e
		if type(tree) == 'table' then
			local list = tree.flames or {}
			list[#list + 1] = e
			tree.flames = list
		end
		return e
	end,
	-- stops a flame that flame_at returned (released on the next frame)
	flame_stop = function(e)
		if type(e) == 'table' then e.to = 0 end
	end,
	-- debug submod: how this battle started (settings, MCT choices, caves; nil before), and the state now
	debug_start = function() return start_info end,
	debug_state = function()
		return { tick = tick, trees = trees ~= nil, fire = fire ~= nil, stopped = stopped, moving = #falling,
			fire_points = fire and #fire.active or 0, fire_max = fire and fire.max or 0, watched = #watched,
			heavy = heavy and #heavy or 0, shots = shot_count, shot_fells = shot_fells, shot_lost = shot_lost }
	end,
}

-- live test hook: only when the test file exists next to Warhammer3.exe
do
	local file = io.open(TEST_FILE, 'r')
	if file then
		file:close()
		_G.altius_timber_test = {
			fell = function(x, z, radius, flaming)
				if trees then
					cause = debug_on and { by = 'test' } or nil
					hit_around(x, z, radius or 20, false, flaming ~= false)
					cause = nil
				end
			end,
			set_fire_points = function(list) fire_points = list end,
			set_crown_min = function(v) crown_min = v end,
			set_kind_scale = function(key, v) if fire and fire.kinds[key] then fire.kinds[key].scale = v end end,
			-- switch the scene of a kind for the next felled trees; file = file name of a scene in the cache
			set_fire_scene = function(key, file)
				if not fire_world then return 'no world yet' end
				fire_stop_all()
				local ok, f = pcall(fire_setup, fire_world, { [key] = file })
				if not ok or not f then return 'not in the cache: ' .. tostring(file) end
				fire = f
				return 'scene of ' .. key .. ' now ' .. (f.kinds[key] and f.kinds[key].name:gsub(string.char(92), '/') or 'none')
			end,
			status = function()
				local felled = 0
				if trees then for _, t in ipairs(trees.list) do if t.felled then felled = felled + 1 end end end
				local kinds, pooled = {}, 0
				if fire then
					for key, kind in pairs(fire.kinds) do
						kinds[#kinds + 1] = key .. '=' .. kind.name:gsub(string.char(92), '/'):match('([^/]+)$')
						pooled = pooled + #kind.pool
					end
					table.sort(kinds)
				end
				return ('trees %s felled %d falling %d fire %s active %d pool %d dead %d stopped %s kinds %s'):format(
					trees and #trees.list or '-', felled, #falling, fire and table.concat(kinds, ',') or 'off',
					fire and #fire.active or 0, pooled, fire and #fire.dead or 0, tostring(stopped),
					trees and ('tree %d shrub %d rock %d stump %d'):format(trees.kinds.tree, trees.kinds.shrub, trees.kinds.rock,
						trees.kinds.stump) or '-')
			end,
		}
	end
end

local function register_callbacks()
	bm:repeat_callback(function()
		if stopped then return end
		local t0 = debug_on and os.clock()
		local ok, err = pcall(on_tick)
		if not ok then
			stopped = true
			pcall(fire_fail, 'tick error', err)
			dbg('stop', 'tick error', err)
		end
		if t0 then dbg('tick_time', os.clock() - t0, #falling, fire and #fire.active or 0) end
	end, TICK_MS, 'altius_timber_tick')
	bm:repeat_real_callback(function()
		if stopped or (#falling == 0 and not (fire and #fire.active > 0)) then return end
		local t0 = debug_on and os.clock()
		local ok, err = pcall(pose_falls)
		if not ok then
			stopped = true
			pcall(fire_fail, 'frame error', err)
			dbg('stop', 'frame error', err)
		end
		if t0 then dbg('frame_time', os.clock() - t0, #falling, fire and #fire.active or 0) end
	end, FRAME_MS, 'altius_timber_frame')
	-- no engine draw calls once the battle is over (the scene players may be freed with the battle)
	bm:register_phase_change_callback('Complete', function() pcall(fire_stop_all); fire = nil; dbg('complete') end)
end

-- reads the settings, then installs the caves and starts the callbacks (once)
local function begin(why)
	if begun then return end
	begun = true
	local from_mct = read_settings()
	apply_settings()
	local installed = false
	if CFG.enable then
		installed = install_caves()
		if installed then
			local ok = pcall(register_callbacks)
			if not ok then stopped = true end
		end
	end
	if not CFG.enable or not installed then stopped = true end
	start_info = { why = why, from_mct = from_mct, settings_error = settings_error, choices = choices, cfg = CFG,
		installed = installed, install_why = install_why, direction = dir_buffer ~= nil, shot = shot_buffer ~= nil,
		started = not stopped,
		test_mode = test_mode }
	if test_mode then
		local keys = {}
		for key in pairs(CFG) do keys[#keys + 1] = key end
		table.sort(keys)
		local parts = {}
		for _, key in ipairs(keys) do parts[#parts + 1] = key .. '=' .. tostring(CFG[key]) end
		local picked = {}
		for _, key in ipairs({ 'enable', 'strength', 'fire_mode', 'monsters', 'effects' }) do
			if choices[key] ~= nil then picked[#picked + 1] = key .. '=' .. tostring(choices[key]) end
		end
		test_log(('---- battle start (%s): settings from %s (%s); started %s, caves %s, direction cave %s; %s'):format(
			why, from_mct and 'MCT' or 'defaults', table.concat(picked, ' '), tostring(not stopped), tostring(installed),
			tostring(dir_buffer ~= nil), table.concat(parts, ' ')))
	end
end

-- MCT reads its saved values after every mod script has loaded (ScriptEventAllModsLoaded, which it hears first) and
-- then fires MctInitialized: start on that. Our own ScriptEventAllModsLoaded listener runs after MCT's, so it only
-- starts the script if MCT did not. Without MCT (or without core), start at once with the defaults.
do
	local waits = false
	if type(get_mct) == 'function' and type(core) == 'table' then
		waits = pcall(function()
			core:add_listener('altius_timber_mct', 'MctInitialized', true, function() begin('MCT ready') end, false)
			core:add_listener('altius_timber_mods_loaded', 'ScriptEventAllModsLoaded', true,
				function() begin('all mods loaded') end, false)
		end)
	end
	if not waits then begin('no MCT') end
end
