
-- Jacob's Tabletop Caps overrides
-- Total War: WARHAMMER III
-- Load after SFO and the 3x Unit Size submod.

local jacob_ttc_overrides = {

    -- CHAOS DWARFS: CORE

    {"wh3_dlc23_chd_inf_infernal_guard_fireglaives", "core"},

    -- OGRE KINGDOMS: SPECIAL

    {"wh3_main_ogr_inf_leadbelchers_0", "special", 1},
    {"wh3_dlc26_ogr_inf_golgfags_maneaters", "special", 2},

    -- OGRE KINGDOMS: RARE

    {"wh3_main_ogr_cav_crushers_0", "rare", 1},
    {"wh3_main_ogr_cav_crushers_1", "rare", 1},

    {"wh3_main_ogr_mon_stonehorn_0", "rare", 2},
    {"wh3_main_ogr_mon_stonehorn_1", "rare", 2},

    {"wh3_dlc26_ogr_mon_thundertusk", "rare", 2},

    -- BRETONNIA: RARE

    {"wh_dlc07_brt_art_blessed_field_trebuchet_0", "rare", 1}

}

local ttc = core:get_static_object("tabletopcaps")

if ttc then
    ttc.add_setup_callback(function()
        ttc.add_unit_list(jacob_ttc_overrides, true)
    end)
end
