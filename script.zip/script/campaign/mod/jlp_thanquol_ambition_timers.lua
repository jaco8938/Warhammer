-- -2 exempts a ritual that was already active when this add-on was installed.
local faction_key = "wh3_dlc29_skv_clan_scruten"
local deadline_key = "jlp_thanquol_ambition_unlock_turn"
local installed_key = "jlp_thanquol_ambition_timers_initialized"
local grandfathered = -2

local function minimum_turns(plan)
    local key = plan:magic_plan_base_token()
    if key == "wh3_dlc29_magic_pull_moon_1" then
        return 13
    elseif key and key:match("^wh3_dlc29_magic_summon_verminlord_") then
        return 6
    end
    return 0
end

cm:add_first_tick_callback(function()
    local faction = cm:get_faction(faction_key)
    if not faction or not faction:is_human() then
        return
    end

    local function record_plans(on_first_install)
        local model = cm:model()
        local states = model:shared_states_manager()
        local manager = model:chaotic_plans_manager()
        local regions = model:world():region_manager():region_list()
        local turn = cm:turn_number()

        for i = 0, regions:num_items() - 1 do
            local region = regions:item_at(i)
            local deadline = states:get_state_as_float_value(region, deadline_key)
            local plan = manager:get_active_plan_by_region(region, faction)
            if plan and not plan:is_null_interface() and plan:type_key() == "magic" then
                if not deadline or deadline == 0 or deadline == -1 then
                    local unlock_turn = on_first_install and grandfathered or turn + minimum_turns(plan)
                    cm:set_script_state(region, deadline_key, unlock_turn)
                end
            elseif deadline and (deadline > 0 or deadline == grandfathered) then
                cm:set_script_state(region, deadline_key, 0)
            end
        end
    end

    record_plans(not cm:get_saved_value(installed_key))
    cm:set_saved_value(installed_key, true)

    -- Query the campaign model, independently of the local player's UI.
    core:add_listener("JlpThanquolTimersCreated", "ChaoticPlanCreatedEvent", true,
        function() record_plans(false) end, true)

    -- Also capture the creation round before it advances if the engine sent the event early.
    core:add_listener("JlpThanquolTimersEndTurn", "FactionTurnEnd",
        function(context) return context:faction():name() == faction_key end,
        function() record_plans(false) end, true)
end)
