-- Personal allegiance bonus for Zhatan only

local target_faction = "wh3_dlc23_chd_zhatan"
local bundle_key = "dcb_allied_recruitment_add_points"
local allegiance_multiplier = 2400

local function apply_zhatan_allegiance_bonus()

    local faction = cm:get_faction(target_faction)

    if faction
        and not faction:is_null_interface()
        and faction:is_human() then

        local bundle = cm:create_new_custom_effect_bundle(bundle_key)

        bundle:add_effect(
            "wh3_main_effect_allegiance_points_mod",
            "faction_to_faction_own_unseen",
            allegiance_multiplier
        )

        cm:apply_custom_effect_bundle_to_faction(bundle, faction)

    end

end

cm:add_first_tick_callback(function()
    apply_zhatan_allegiance_bonus()
end)