-- Timber!: settings page for the Mod Configuration Tool (MCT, Workshop 2927955021). Optional: without MCT, Timber! uses
-- its defaults. Five simple choices; each sets several values of the CFG table in script/battle/mod/altius_timber.lua
-- (PRESETS there). Keep the option keys, choice keys and defaults of both files the same.
-- The defaults play like Timber! v1 (one hit fells a tree, no fire, no monsters); the other choices turn on the rest.
-- A battle reads these values once, while it loads: a campaign battle the campaign's values, a quick or custom battle
-- the values set in the main menu.
local mct = type(get_mct) == 'function' and get_mct() or nil
if not mct then return end

local ok, err = pcall(function()
	local mod = mct:register_mod('altius_timber')
	mod:set_title('Timber!')
	mod:set_author('Altius')
	mod:set_description('Battle trees fall, burn and get trampled. The defaults play like Timber! v1: one hit knocks a tree down, no fire, no monsters. Turn the rest on here. Requires memreader Plus. Changes take effect in the next battle.')

	local function checkbox(key, text, tooltip, default)
		local o = mod:add_new_option(key, 'checkbox')
		o:set_text(text)
		o:set_tooltip_text(tooltip)
		o:set_default_value(default)
		return o
	end

	-- values: { key, text, tooltip }; the default is the one named
	local function dropdown(key, text, tooltip, values, default)
		local o = mod:add_new_option(key, 'dropdown')
		o:set_text(text)
		o:set_tooltip_text(tooltip)
		local list = {}
		for _, v in ipairs(values) do list[#list + 1] = { key = v[1], text = v[2], tt = v[3], is_default = v[1] == default } end
		o:add_dropdown_values(list)
		o:set_default_value(default)
		return o
	end

	mod:add_new_section('timber', 'Timber!')
	checkbox('enable', 'Enable Timber!',
		'Off: trees stay as in the vanilla game.', true)
	dropdown('strength', 'Tree strength',
		'How much it takes to knock a tree down.', {
			{ 'weak', 'Weak (v1)', 'Any hit knocks a tree down, as in Timber! v1.' },
			{ 'normal', 'Normal', 'A tree takes about three hits. Big blasts like the Comet of Casandora knock down everything they cover at once.' },
			{ 'strong', 'Strong', 'A tree takes about five hits. Only very big blasts knock down everything at once.' },
		}, 'weak')
	dropdown('fire_mode', 'Fire',
		'What flaming attacks (fire spells, the Sunmaker, flame cannons) do to trees.', {
			{ 'off', 'Off (v1)', 'Flaming attacks only knock trees down, like any other attack, as in Timber! v1. Bushes and flowers are left alone.' },
			{ 'burn', 'Burning trees', 'Trees knocked down by flaming attacks burn. The fire does not spread.' },
			{ 'small', 'Small wildfires', 'Fire spreads to a few nearby trees and bushes, then dies out.' },
			{ 'forest', 'Forest fires', 'Fire spreads from tree to tree. Each fire is stronger or weaker by chance: some die out soon, some burn down a whole forest.' },
		}, 'off')
	checkbox('monsters', 'Monsters knock down trees',
		'The biggest monsters walk straight through forests; other big monsters knock down the trees in front of them while they fight. Off in Timber! v1.', false)
	dropdown('effects', 'Fire effects',
		'How many fire effects can burn at once.', {
			{ 'normal', 'Normal', 'As many as Timber! needs.' },
			{ 'fewer', 'Fewer', 'Fewer at once, for slower PCs. Big fires spread more slowly.' },
		}, 'normal')
end)
if not ok then
	pcall(function() if type(ModLog) == 'function' then ModLog('Timber!: MCT settings page failed: ' .. tostring(err)) end end)
end
